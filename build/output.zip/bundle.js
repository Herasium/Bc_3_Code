(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.beginHiddenCallStack = beginHiddenCallStack;
exports.endHiddenCallStack = endHiddenCallStack;
exports.expectedError = expectedError;
exports.injectVirtualStackFrame = injectVirtualStackFrame;
var _Object$getOwnPropert;
const ErrorToString = Function.call.bind(Error.prototype.toString);
const SUPPORTED = !!Error.captureStackTrace && ((_Object$getOwnPropert = Object.getOwnPropertyDescriptor(Error, "stackTraceLimit")) == null ? void 0 : _Object$getOwnPropert.writable) === true;
const START_HIDING = "startHiding - secret - don't use this - v1";
const STOP_HIDING = "stopHiding - secret - don't use this - v1";
const expectedErrors = new WeakSet();
const virtualFrames = new WeakMap();
function CallSite(filename) {
  return Object.create({
    isNative: () => false,
    isConstructor: () => false,
    isToplevel: () => true,
    getFileName: () => filename,
    getLineNumber: () => undefined,
    getColumnNumber: () => undefined,
    getFunctionName: () => undefined,
    getMethodName: () => undefined,
    getTypeName: () => undefined,
    toString: () => filename
  });
}
function injectVirtualStackFrame(error, filename) {
  if (!SUPPORTED) return;
  let frames = virtualFrames.get(error);
  if (!frames) virtualFrames.set(error, frames = []);
  frames.push(CallSite(filename));
  return error;
}
function expectedError(error) {
  if (!SUPPORTED) return;
  expectedErrors.add(error);
  return error;
}
function beginHiddenCallStack(fn) {
  if (!SUPPORTED) return fn;
  return Object.defineProperty(function (...args) {
    setupPrepareStackTrace();
    return fn(...args);
  }, "name", {
    value: STOP_HIDING
  });
}
function endHiddenCallStack(fn) {
  if (!SUPPORTED) return fn;
  return Object.defineProperty(function (...args) {
    return fn(...args);
  }, "name", {
    value: START_HIDING
  });
}
function setupPrepareStackTrace() {
  setupPrepareStackTrace = () => {};
  const {
    prepareStackTrace = defaultPrepareStackTrace
  } = Error;
  const MIN_STACK_TRACE_LIMIT = 50;
  Error.stackTraceLimit && (Error.stackTraceLimit = Math.max(Error.stackTraceLimit, MIN_STACK_TRACE_LIMIT));
  Error.prepareStackTrace = function stackTraceRewriter(err, trace) {
    let newTrace = [];
    const isExpected = expectedErrors.has(err);
    let status = isExpected ? "hiding" : "unknown";
    for (let i = 0; i < trace.length; i++) {
      const name = trace[i].getFunctionName();
      if (name === START_HIDING) {
        status = "hiding";
      } else if (name === STOP_HIDING) {
        if (status === "hiding") {
          status = "showing";
          if (virtualFrames.has(err)) {
            newTrace.unshift(...virtualFrames.get(err));
          }
        } else if (status === "unknown") {
          newTrace = trace;
          break;
        }
      } else if (status !== "hiding") {
        newTrace.push(trace[i]);
      }
    }
    return prepareStackTrace(err, newTrace);
  };
}
function defaultPrepareStackTrace(err, trace) {
  if (trace.length === 0) return ErrorToString(err);
  return `${ErrorToString(err)}\n    at ${trace.join("\n    at ")}`;
}
0 && 0;



},{}],2:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Background = Background;
function Background(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page,
    Display = _require.Display;
  var display = new Display();
  var page = new Page("Background");
  var wave1 = page.image("wave1.svg");
  var wave2 = page.image("wave2.svg");
  page.html("\n        <div id=\"blur\"></div>\n        <div class=\"elipse\" id=\"e-1\"></div>\n        <div class=\"elipse\" id=\"e-2\"></div>\n    ");
  console.log(display.get("background"));
  page.css("\n        body {\n            background-color: ".concat(display.get("background").color, ";\n        }\n        #blur {\n            backdrop-filter: blur(").concat(display.get("background")["blur"], ");\n            z-index: -5;\n            position: fixed;\n            top: 0;\n            left: 0;\n            height: 100%;\n            width: 100%;\n        }\n        \n        .elipse {\n            border-radius: 458px;\n            width: 458px;\n            height: 458px;\n            z-index: -6;\n            position: fixed;\n        }\n        \n        #e-1 {\n            background: ").concat(display.get("background")["elipse-color"][0], ";\n            top:0;\n            left:0;\n        }\n        \n        #e-2 {\n            background:").concat(display.get("background")["elipse-color"][1], ";\n            bottom: 0;\n            right:0;\n        }\n        @media screen and (max-width: 1270px){\n            #blur {\n              height: 100%;\n            }\n            .elipse {\n              height: 48vw;\n              width: 48vw;\n            }\n          }\n    "));
  page.render();
}

},{"../lib/Framework.mjs":10}],3:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Comment = Comment;
function Comment(router, post, parent, post_id) {
  var _require = require("../scripts/api.mjs"),
    ViewPost = _require.ViewPost,
    IsLogedIn = _require.IsLogedIn,
    CommentLiked = _require.CommentLiked,
    LikeComment = _require.LikeComment,
    GetProfile = _require.GetProfile;
  var _require2 = require("../lib/Framework.mjs"),
    Module = _require2.Module,
    Display = _require2.Display;
  var display = new Display();
  var module = new Module("Comment");
  var blank_logo = module.image("logo_blank.svg");
  function timeConverter(UNIX_timestamp) {
    var a = new Date(UNIX_timestamp * 1000);
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var year = a.getFullYear();
    var month = months[a.getMonth()];
    var date = a.getDate();
    var hour = ('0' + a.getHours()).slice(-2); // Pad single-digit hours with leading zero
    var min = ('0' + a.getMinutes()).slice(-2); // Pad single-digit minutes with leading zero
    var sec = ('0' + a.getSeconds()).slice(-2); // Pad single-digit seconds with leading zero
    var time = date + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec;
    return time;
  }
  module.html("\n    <div id=\"comment\">\n        <div id=\"comment-top-container\">\n            <img id=\"comment-img\" class=\"profile-picture\" class=\"text\"></img>\n            <div id=\"comment-user\" class=\"text username\">Loading...</div>\n            <div class=\"comment-badges-container\"></div>\n            <div id=\"comment-meta\" class=\"text timestamp\" >BlockCoin Browser App - Loading...</div>\n        </div>\n        <div id=\"comment-data\" class=\"text data\">Loading...</div>\n        <div id=\"comment-stats\" class=\"stats text\">\n            <span class=\"material-symbols-outlined like-button\">favorite</span> \n            <span class=\"likes\">0</span>\n            <div id=\"reply-button\" class=\"reply-button\"><span class=\"material-symbols-outlined\">reply</span> Reply </div> \n        </div>\n    </div>\n    <div id=\"comment-reply\" class=\"comment-reply\">\n    </div>\n    ");
  module.css("\n    .a-blockcoin {\n        width:24px;\n        height:24px;\n    }\n    .like-button {\n        transition-duration: 0.5s;\n        cursor:pointer;\n    }\n    .like-button:hover {\n        font-size: 26px;\n    }\n    .a-blockcoin:hover {\n        transition-duration: 0.5s;\n        cursor:pointer;\n        width:26px;\n        height:26px;\n    }\n    .liked {\n        color:#FF0000;\n        font-variation-settings:\n        'FILL' 1,\n        'wght' 400,\n        'GRAD' 0,\n        'opsz' 24\n    }\n    #comment {\n        background: ".concat(display.get("comment")["background"], ";\n        width:100%;\n        min-width:450px;\n        height: 100%;\n        top:0;\n        left:0;\n        border: ").concat(display.get("comment")["border"], ";\n        border-radius: ").concat(display.get("comment")["border-radius"], "\n    }\n    .comment-reply {\n        width:90%;\n        height: fit-content;\n    }\n    .comment-badge {\n        font-size: 25px;\n        color: ").concat(display.get("badge")["color"], ";\n  \n      }\n      #comment-badges-container {\n        width:20%;\n        display:flex;\n        flex-direction:row;\n        justify-content:flex-start;\n        align-items:center;\n        margin:10px;\n        border:").concat(display.get("badge")["border"], ";\n        border-radius:").concat(display.get("badge")["border-radius"], ";\n      }\n    .text {\n        font-family: '").concat(display.get("text")["font"], "', sans-serif;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        font-size: ").concat(display.get("text")["size"][1], ";\n        color:").concat(display.get("text")["color"], ";\n    }\n\n    #comment-img {\n        cursor:pointer;\n        border-radius:256px;\n        width: 48px;\n        height: 48px;\n        margin: 10px;\n    }\n\n    #comment-user {\n        cursor:pointer;\n        margin: 10px;\n        margin-left:0;\n    }\n\n    #comment-top-container {\n        position:relative;\n        top:0;\n        left:0;\n        width:100%;\n        height:fit-content;\n        display:flex;\n        justify-content: start;\n        align-items: center;\n        flex-direction: row;\n    \n    }\n    #reply-button {\n        cursor:pointer;\n        transition-duration: 0.5s;\n        font-family: '").concat(display.get("text")["font"], "', sans-serif;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        font-size: ").concat(display.get("text")["size"][1], ";\n        color:").concat(display.get("text")["color"], ";\n        height:auto;\n        width:auto;\n        text-align:center;\n        width:fit-content;\n      }\n      #reply-button:hover {\n        font-size: 26px;\n      }\n    #comment-meta {\n        margin: 10px;\n        font-weight: 300;\n        font-size: 17px;\n    }\n    #comment-stats {\n        margin: 10px;\n        bottom:0;\n        position:relative;\n        right:0;\n        text-align:right;\n        font-weight: 300;\n        font-size: 17px;\n    }\n    #comment-data {\n        margin: 10px;\n    }\n    "));
  module.parent(parent);
  function on_render() {
    var buyer = null;
    module.div.id = post["id"];
    document.getElementById("comment-reply").id = post["id"] + "-container";
    var text = post["data"];
    text = text.replace(/>/g, '');
    text = text.replace(/</g, '');
    var htmlContent = marked.parse(text);
    module.div.getElementsByClassName("username")[0].innerText = post["user"];
    module.div.getElementsByClassName("data")[0].innerHTML = htmlContent;
    module.div.getElementsByClassName("timestamp")[0].innerText = "".concat(timeConverter(post["date"]));
    module.div.getElementsByClassName("reply-button")[0].onclick = function () {
      router.navigateTo("/comment/" + post_id + "/" + post["id"]);
    };
    if (buyer == null) {
      module.div.getElementsByClassName("profile-picture")[0].src = post["profile-picture"];
    } else {
      module.div.getElementsByClassName("profile-picture")[0].src = buyer["profile-picture"];
    }
    module.div.getElementsByClassName("likes")[0].innerText = post["likes"];
    module.div.getElementsByClassName("profile-picture")[0].onclick = function () {
      router.navigateTo("/profile/" + post["user-id"]);
    };
    module.div.getElementsByClassName("username")[0].onclick = function () {
      router.navigateTo("/profile/" + post["user-id"]);
    };
    var container = module.div.getElementsByClassName("comment-badges-container")[0];
    var badges = ["award_star", "verified", "shield_person", "smart_toy", "local_fire_department", "science", 'bug_report'];
    var titles = ["BlockCoin Admin", "Verified Account", "BlockCoin Staff", "Bot Account", "BlockCoin Premium", "Beta Tester", "Bug Report"];
    for (var i = 0; i < post["badges"].length; i++) {
      var span = document.createElement("span");
      span.className = "material-symbols-outlined comment-badge";
      span.innerHTML = badges[post["badges"][i]];
      span.title = titles[post["badges"][i]];
      // Append the span element to the container div
      container.appendChild(span);
    }
    var liked = false;
    var sent_requests = false;
    function check_scroll() {
      var targetDiv = module.div;
      var bounding = targetDiv.getBoundingClientRect();

      // Checking if the div is in the viewport
      if (bounding.top >= 0 && bounding.left >= 0 && bounding.bottom <= (window.innerHeight || document.documentElement.clientHeight) && bounding.right <= (window.innerWidth || document.documentElement.clientWidth)) {
        if (IsLogedIn() && sent_requests == false) {
          sent_requests = true;
          CommentLiked(post_id, post["id"]).then(function (data) {
            console.log(data);
            liked = data["liked"];
            if (data["liked"]) {
              module.div.getElementsByClassName("like-button")[0].classList.add('liked');
            }
          });
          module.div.getElementsByClassName("like-button")[0].onclick = function () {
            console.log("Clicked");
            if (liked) {
              liked = false;
              module.div.getElementsByClassName("like-button")[0].classList.remove('liked');
              module.div.getElementsByClassName("likes")[0].innerText = parseInt(module.div.getElementsByClassName("likes")[0].innerText) - 1;
              LikeComment(post["id"], post_id);
            } else {
              liked = true;
              module.div.getElementsByClassName("like-button")[0].classList.add('liked');
              module.div.getElementsByClassName("likes")[0].innerText = parseInt(module.div.getElementsByClassName("likes")[0].innerText) + 1;
              LikeComment(post["id"], post_id);
            }
          };
        }
      }
    }
    check_scroll();
    window.addEventListener('scroll', function () {
      check_scroll();
    });
  }
  module.on_render(on_render);
  var element = document.getElementById(post["id"]);
  if (element == null) {
    module.render();
  } else {
    return "";
  }
}

},{"../lib/Framework.mjs":10,"../scripts/api.mjs":29}],4:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Fonts = Fonts;
function Fonts(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page,
    Display = _require.Display;
  var display = new Display();
  var page = new Page("Fonts");
  page.html("\n    <link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">\n    <link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>\n    <link href=\"https://fonts.googleapis.com/css2?family=".concat(display.get("text")["font-code"], ":ital,wght@0,300;0,400;0,500;0,600;0,700;1,400;1,600&display=swap\" rel=\"stylesheet\">\n    <link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200\" />\n    "));
  page.css("\n    .material-symbols-outlined {\n      font-variation-settings:\n      'FILL' 0,\n      'wght' 400,\n      'GRAD' 0,\n      'opsz' 24\n    }\n\n    .material-symbols-filled {\n        font-variation-settings:\n        'FILL' 1,\n        'wght' 400,\n        'GRAD' 0,\n        'opsz' 24\n      }\n    ");
  page.render();
}

},{"../lib/Framework.mjs":10}],5:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Footer = Footer;
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function Footer(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page,
    Display = _require.Display;
  var page = new Page("Footer");
  var display = new Display();
  page.html("\n    <footer>\n    <div id=\"copy\">\xA9 BlockCoin 2024</div>\n    <div class=\"container-4\">\n      <div class=\"container-titles\">\n        <div class=\"title\">Community</div>\n        <div class=\"title\">Website</div>\n        <div class=\"title\">Services</div>\n      </div>\n      <div class=\"container-links\">\n        <div class=\"container-link\">\n          <a class=\"link\" id=\"discord\">Discord</a>\n          <a class=\"link\" id=\"scratch\">Scratch</a>\n          <a class=\"link\" id=\"twitter\">X (Twitter)</a>\n        </div>\n        <div class=\"container-link\">\n          <a class=\"link\" id=\"login\">Login</a>\n          <a class=\"link\" id=\"register\">Register</a>\n          <a class=\"link\" id=\"dashboard\">Dashboard</a>\n        </div>\n        <div class=\"container-link\">\n          <a class=\"link\" id=\"status\">Status</a>\n          <a class=\"link\" id=\"api\">Api</a>\n          <a class=\"link\" id=\"docs\">Docs</a>\n        </div>\n      </div>\n    </div>\n    </footer>\n    ");
  page.css("\n    footer {\n        backdrop-filter: blur(".concat(display.get("navbar")["blur"], ");\n        z-index:1000;\n        position: fixed;\n        left: 0;\n        width: 100%;\n        bottom: 0;\n        background: ").concat(display.get("navbar")["background"], ";\n      }\n      \n      .container-4 {\n        width:100%;\n        height:10%;\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        flex-direction:column;\n      }\n      \n      .container-titles {\n        margin-bottom: 10px;\n        width:50%;\n        display: flex;\n        justify-content: space-evenly;\n        align-items: center;\n        flex-direction:row;\n      }\n      \n      .title {\n        width: 150px;\n        font-family: ").concat(display.get("text")["font"], ", sans-serif;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        color:").concat(display.get("text")["color"], ";\n        font-size: ").concat(display.get("text")["size"][1], ";\n        text-align: center;\n      }\n      \n      .container-links {\n        margin-bottom: 30px;\n        width:50%;\n        display: flex;\n        justify-content: space-evenly;\n        align-items: center;\n        flex-direction:row;\n      }\n      \n      .container-link {\n        width: 150px;\n        height: 100%;\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        flex-direction:column;\n      }\n      \n      .link {\n        font-family: ").concat(display.get("text")["font"], ", sans-serif;\n        font-weight: ").concat(display.get("text")["font-weight-light"], ";\n        color:").concat(display.get("text")["color"], ";\n        font-size: ").concat(display.get("text")["size"][0], ";\n        cursor:pointer;\n      }\n      \n      #copy {\n        position:absolute;\n        font-family:  ").concat(display.get("text")["font"], ", sans-serif;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        color:").concat(display.get("text")["color"], ";\n        font-size: ").concat(display.get("text")["size"][0], ";\n        bottom: 0;\n        left:0;\n        margin:10px;\n      }\n\n      p{color:").concat(display.get("text")["color"], "}\n\n      @media screen and (max-width: 1270px){\n        footer {\n          position:absolute;\n          top:100%;\n        }\n        #copy {\n          top:100%\n        }\n      }\n      \n      \n      @media screen and (max-width: 550px){\n        footer: {\n          display:none;\n        }\n\n        #copy {\n          margin: 0;\n          top:0;\n          width:100%;\n          left:0;\n          text-align: center;\n        }\n        .container-links {\n          width: 100%;\n          margin-bottom: 0px;\n        }\n        .container-titles {\n          width: 100%;\n          margin-bottom: 0px;\n        }\n        footer {\n          overflow: hidden;\n          height: 20%;\n        }\n        .container-4{\n          position: absolute;\n          bottom: 30%;\n        }\n      }\n  }\n      "));
  function on_render() {
    var buttons = page.document.getElementsByClassName("link");
    var buttonPressed = function buttonPressed(e) {
      router.navigateTo("/" + e.target.id);
    };
    var _iterator = _createForOfIteratorHelper(buttons),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var button = _step.value;
        button.addEventListener("click", buttonPressed);
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
  }
  page.on_render(on_render);
  page.render();
}

},{"../lib/Framework.mjs":10}],6:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Navbar = Navbar;
function Navbar(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page,
    Display = _require.Display;
  var _require2 = require("../scripts/api.mjs"),
    IsLogedIn = _require2.IsLogedIn,
    GetProfile = _require2.GetProfile;
  var _require3 = require("../scripts/cookies.mjs"),
    setCookie = _require3.setCookie,
    getCookie = _require3.getCookie,
    checkCookie = _require3.checkCookie;
  var page = new Page("Navbar");
  var display = new Display();
  var logo = page.image("logo.svg");
  page.html("\n      <div id=\"navbar\">\n          <img src=\"".concat(display.get("logo")["url"], "\" id=\"logo\" alt=\"Blockcoin's logo, in the form of a coin.\"></img>\n          <div class=\"container-3 not-logged\">\n            <div class=\"trans-button\" id=\"register\">Register</div>\n            <div class=\"trans-button\" id=\"login\">Login</div>\n            <div class=\"trans-button\" id=\"explore-1\">Trending</div>\n          </div>\n          <div class=\"container-3 logged\">\n            <div class=\"trans-button\" id=\"feed\">Feed</div>\n            <div class=\"trans-button\" id=\"explore-2\">Trending</div>\n            <div class=\"trans-button\" id=\"random\">Explore</div>\n          </div>\n          <img src=\"").concat(logo, "\" id=\"profile\" class=\"logged\"alt=\"User's profile picture\"></img>\n      </div>\n      "));
  page.css("\n      #navbar {\n          backdrop-filter: blur(".concat(display.get("navbar")["blur"], ");\n          z-index:100;\n          display: flex;\n          justify-content: space-between;\n          align-items: center;\n          position: fixed;\n          top:0;\n          left:0;\n          width:100%;\n          height:7.5%;\n          background:").concat(display.get("navbar")["background"], "\n        }\n        \n        #logo {\n          margin-left:2.5%;\n          width: auto;\n          height: 85%;\n          display:block;\n          cursor:pointer;\n          object-fit: cover;\n          z-index:100;\n        }\n        \n        #profile {\n          border-radius:256px;\n          object-fit: cover;\n          margin-right:2.5%;\n          position:relative;\n          width: auto;\n          height: 85%;\n          display:block;\n          cursor:pointer;\n          z-index:100;\n        }\n\n        .trans-button {\n          position:relative;\n          cursor:pointer;\n          color: ").concat(display.get("text")["color"], ";\n          font-family: ").concat(display.get("text")["font"], ";\n          font-size: ").concat(display.get("text")["size"][1], ";\n          font-weight: ").concat(display.get("text")["font-weight"], ";\n          z-index:100;\n        }\n        .not-logged {\n          margin-left:2.5%;\n        }\n        .container-3 {\n          display: flex;\n          justify-content: space-between;\n          align-items: center;\n          gap:30px\n        }\n      \n        @media screen and (max-width: 550px){\n          \n          #navbar {\n            display: flex;\n            justify-content: center;\n            align-items: center;\n            position: absolute;\n            flex-direction: column;\n            margin-top: 20px;\n          }\n          .container-3 {\n            display: flex;\n            justify-content: space-around;\n            align-items: center;\n            width: 100%;\n          }\n          .trans-button {\n            width: 30%;\n            text-align: center;\n          }\n        }\n    }\n      "));
  function on_render() {
    if (IsLogedIn()) {
      var elements = document.getElementsByClassName('not-logged');
      for (var i = 0; i < elements.length; i++) {
        elements[i].style.display = 'none';
      }
      if (checkCookie("v1-profile-picture") == false) {
        GetProfile(getCookie("v1-id")).then(function (data) {
          console.log(data);
          setCookie("v1-profile-picture", data["profile-picture"], 365);
          document.getElementById("profile").src = getCookie("v1-profile-picture");
        });
      } else {
        document.getElementById("profile").src = getCookie("v1-profile-picture");
      }
      document.getElementById("profile").onclick = function () {
        router.navigateTo("/dashboard");
      };
      document.getElementById("feed").onclick = function () {
        router.navigateTo("/feed");
      };
    } else {
      document.getElementById("register").onclick = function () {
        router.navigateTo("/register");
      };
      document.getElementById("login").onclick = function () {
        router.navigateTo("/login");
      };
      var elements = document.getElementsByClassName('logged');
      for (var i = 0; i < elements.length; i++) {
        elements[i].style.display = 'none';
      }
    }
    document.getElementById("explore-1").onclick = function () {
      router.navigateTo("/trending");
    };
    document.getElementById("explore-2").onclick = function () {
      router.navigateTo("/trending");
    };
    document.getElementById("random").onclick = function () {
      router.navigateTo("/explore");
    };
    document.getElementById("logo").onclick = function () {
      router.navigateTo("/");
    };
  }
  page.on_render(on_render);
  page.render();
}

},{"../lib/Framework.mjs":10,"../scripts/api.mjs":29,"../scripts/cookies.mjs":30}],7:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.NewPostButton = NewPostButton;
function NewPostButton(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page,
    Display = _require.Display;
  var _require2 = require("../scripts/api.mjs"),
    IsLogedIn = _require2.IsLogedIn;
  var page = new Page("NewPostButton");
  var display = new Display();
  page.html("\n        <span class=\"material-symbols-outlined\" id=\"new_button\">add</span>\n    ");
  page.css("\n    #new_button {\n      transition-duration: 0.5s;\n      z-index:10000;\n      width: 94px;\n      height: 94px;\n      border-radius:256px;\n      background-color:".concat(display.get("new")["background"][4], ";\n      position:fixed;\n      bottom:25px;\n      right:25px;\n      color: ").concat(display.get("new")["color"][4], ";\n      text-align: center;\n      vertical-align: middle;\n      line-height: 94px;\n      cursor:pointer;\n      font-size: 72px;\n      border:").concat(display.get("new")["border"][4], ";\n    }\n    #new_button:hover {\n        width: 100px;\n        height: 100px;\n        font-size: 78px;\n        line-height: 100px;\n    }\n    \n    "));
  function on_render() {
    if (IsLogedIn() == false) {
      document.getElementById("new_button").remove();
    } else {
      document.getElementById("new_button").onclick = function () {
        router.navigateTo("/new");
      };
    }
  }
  page.on_render(on_render);
  page.render();
}

},{"../lib/Framework.mjs":10,"../scripts/api.mjs":29}],8:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Notification = Notification;
function Notification(type, text) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page,
    Module = _require.Module,
    Display = _require.Display;
  var display = new Display();
  var page = undefined;
  var element = document.getElementById('notif-container');
  if (element === null) {
    page = new Page("Notification");
    page.html("\n            <div id=\"notif-container\"></div>\n        ");
    page.css("\n            #notif-container {\n                position:fixed;\n                width:100%;\n                height:90%;\n                display:flex;\n                align-items:center;\n                justify-content:start;\n                flex-direction:column;\n                position:absolute;\n                top:7.5%;\n                left:0;\n                z-index:100;\n            }\n        ");
    page.delete_animation("\n        @keyframes delete {\n            0% {\n              opacity: 1;\n              transform: translateY(0%);\n            }\n            100% {\n              opacity: 0;\n              transform: translateY(10%); /* Adjust the distance you want to move on the y-axis */\n            }\n          }\n        ");
    page.render();
  }
  var module = new Module("Notification", document.getElementById('notif-container'));
  module.html("\n        <div id=\"new-notif\">\n            <span class=\"material-symbols-outlined type\" id=\"type\">more_horiz</span>\n            <div id=\"text\" class=\"notif-text\">Loading...</div>\n        </div>\n    ");
  module.css("\n        #new-notif {\n            backdrop-filter: blur(10px);\n            border: solid white 1px;\n            border-radius: 32px;\n            display:flex;\n            align-items:center;\n            justify-content:start;\n            flex-direction: row;\n            height:auto;\n            width:auto;\n            position:relative;\n            margin:10px;\n            z-index:10000;\n        }\n        #type {\n            color:".concat(display.get("notification")["icon-color"], ";\n            font-weight: ").concat(display.get("text")["size"][4], ";\n            margin-left:10px;\n        }\n        #text {\n            color:").concat(display.get("text")["color"], ";\n            font-family: ").concat(display.get("text")["font"], ";\n            font-size: ").concat(display.get("text")["size"][3], ";\n            font-style: normal;\n            font-weight: ").concat(display.get("text")["font-weight"], ";\n            line-height: normal;\n            width:auto;\n            text-align:center;\n            margin-right:20px;\n            z-index:10000;\n          }\n    "));
  var types = ["check", "close", "info", "help"];
  function on_render() {
    try {
      module.div.getElementsByClassName("notif-text")[0].innerText = text;
      module.div.getElementsByClassName("type")[0].innerText = types[type];
      setTimeout(function () {
        module["delete"]();
        var element = document.getElementById('notif-container');
        if (element !== null) {
          element.remove();
          document.getElementsByTagName("notification")[0].remove();
        }
      }, 6000);
    } catch (_unused) {
      module["delete"]();
      var _element = document.getElementById('notif-container');
      if (_element !== null) {
        _element.remove();
        document.getElementsByTagName("notification")[0].remove();
      }
    }
  }
  module.delete_animation("\n    @keyframes delete {\n        0% {\n          opacity: 1;\n          transform: translateY(0%);\n        }\n        100% {\n          opacity: 0;\n          transform: translateY(10%); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  module.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  module.on_render(on_render);
  module.render();
}

},{"../lib/Framework.mjs":10}],9:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.LivePost = LivePost;
exports.Post = Post;
exports.PreviewPost = PreviewPost;
function Post(router, post, parent) {
  var _require = require("../lib/Framework.mjs"),
    Module = _require.Module,
    Display = _require.Display;
  var _require2 = require("../scripts/api.mjs"),
    ViewPost = _require2.ViewPost,
    IsLogedIn = _require2.IsLogedIn,
    PostLiked = _require2.PostLiked,
    LikePost = _require2.LikePost,
    GetProfile = _require2.GetProfile;
  var display = new Display();
  var module = new Module("Post");
  var blank_logo = module.image("logo_blank.svg");
  function timeConverter(UNIX_timestamp) {
    var a = new Date(UNIX_timestamp * 1000);
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var year = a.getFullYear();
    var month = months[a.getMonth()];
    var date = a.getDate();
    var hour = ('0' + a.getHours()).slice(-2); // Pad single-digit hours with leading zero
    var min = ('0' + a.getMinutes()).slice(-2); // Pad single-digit minutes with leading zero
    var sec = ('0' + a.getSeconds()).slice(-2); // Pad single-digit seconds with leading zero
    var time = date + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec;
    return time;
  }
  module.html("\n    <div id=\"post\" class=\"post\">\n        <div id=\"top-container\">\n            <img id=\"post-img\" class=\"profile-picture\" class=\"text\"></img>\n            <div id=\"post-user\" class=\"text username\">Loading...</div>\n            <div class=\"post-badges-container\"></div>\n        </div>\n        <div id=\"post-data\" class=\"text data\">Loading...</div>\n        <div id=\"post-meta\" class=\"text timestamp\" >BlockCoin Browser App - Loading...</div>\n        <div id=\"post-stats\" class=\"stats text\">\n            <span class=\"material-symbols-outlined\">visibility</span> \n            <span class=\"views\">0</span> \n            <span class=\"material-symbols-outlined like-button\">favorite</span> \n            <span class=\"likes\">0</span> \n            <span class=\"material-symbols-outlined comment-button\">chat</span> \n            <span class=\"comment\">0</span> \n            <img src=\"".concat(blank_logo, "\" class=\"a-blockcoin\" /> \n            <span class=\"blockcoin\">0</span> \n        </div>\n    </div>\n    "));
  module.css("\n    .a-blockcoin {\n        width:24px;\n        height:24px;\n    }\n    .like-button {\n        transition-duration: 0.5s;\n        cursor:pointer;\n    }\n    .comment-button:hover {\n        font-size: 26px;\n    }\n    .comment-button {\n        transition-duration: 0.5s;\n        cursor:pointer;\n    }\n    .like-button:hover {\n        font-size: 26px;\n    }\n    .a-blockcoin:hover {\n        transition-duration: 0.5s;\n        cursor:pointer;\n        width:26px;\n        height:26px;\n    }\n    .liked {\n        color:#FF0000;\n        font-variation-settings:\n        'FILL' 1,\n        'wght' 400,\n        'GRAD' 0,\n        'opsz' 24\n    }\n    #post {\n        background: ".concat(display.get("post")["background"], ";\n        width:100%;\n        height: 100%;\n        top:0;\n        left:0;\n        border: ").concat(display.get("post")["border"], ";\n        border-radius: ").concat(display.get("post")["border-radius"], "\n    }\n    .post-badge {\n        font-size: 25px;\n        color: ").concat(display.get("badge")["color"], ";\n  \n      }\n      #post-badges-container {\n        width:20%;\n        display:flex;\n        flex-direction:row;\n        justify-content:flex-start;\n        align-items:center;\n        margin:10px;\n        border:").concat(display.get("badge")["border"], ";\n        border-radius:").concat(display.get("badge")["border-radius"], ";\n      }\n      .text {\n        font-family: '").concat(display.get("text")["font"], "', sans-serif;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        font-size: ").concat(display.get("text")["size"][1], ";\n        color:").concat(display.get("text")["color"], ";\n    }\n\n\n    #post-img {\n        cursor:pointer;\n        border-radius:256px;\n        width: 48px;\n        height: 48px;\n        margin: 10px;\n    }\n\n    #post-user {\n        cursor:pointer;\n        margin: 10px;\n        margin-left:0;\n    }\n\n    #top-container {\n        position:relative;\n        top:0;\n        left:0;\n        width:100%;\n        height:fit-content;\n        display:flex;\n        justify-content: start;\n        align-items: center;\n        flex-direction: row;\n    \n    }\n\n    #post-meta {\n        margin: 10px;\n        font-weight: 300;\n        font-size: 17px;\n    }\n    #post-stats {\n        margin: 10px;\n        bottom:0;\n        position:relative;\n        right:0;\n        text-align:right;\n        font-weight: 300;\n        font-size: 17px;\n    }\n    #post-data {\n        margin: 10px;\n    }\n    "));
  module.parent(parent);
  function on_render() {
    console.log(post);
    var buyer = null;
    if ("comments" in post) {
      module.div.getElementsByClassName("comment")[0].innerText = Object.keys(post["comments"]).length;
    }
    if (post["buyer"] != "None") {
      GetProfile(post["buyer"]).then(function (value) {
        buyer = value;
        var liked = false;
        module.div.id = post["id"];
        if (buyer == null) {
          module.div.getElementsByClassName("username")[0].innerText = post["user"];
        } else {
          module.div.getElementsByClassName("username")[0].innerText = buyer["display"] + " original by " + post["user"];
        }
        var text = post["data"];
        text = text.replace(/>/g, '');
        text = text.replace(/</g, '');
        var htmlContent = marked.parse(text);
        module.div.getElementsByClassName("data")[0].innerHTML = htmlContent;
        module.div.getElementsByClassName("timestamp")[0].innerText = "BlockCoin Browser App - ".concat(timeConverter(post["date"]));
        if (buyer == null) {
          module.div.getElementsByClassName("profile-picture")[0].src = post["profile-picture"];
        } else {
          module.div.getElementsByClassName("profile-picture")[0].src = buyer["profile-picture"];
        }
        module.div.getElementsByClassName("views")[0].innerText = post["views"];
        module.div.getElementsByClassName("likes")[0].innerText = post["likes"];
        module.div.getElementsByClassName("blockcoin")[0].innerText = post["price"];
        module.div.getElementsByClassName("profile-picture")[0].onclick = function () {
          if (buyer == null) {
            router.navigateTo("/profile/" + post["user-id"]);
          } else {
            router.navigateTo("/profile/" + buyer["id"]);
          }
        };
        if (post["isBuyable"] == true) {
          module.div.getElementsByClassName("a-blockcoin")[0].onclick = function () {
            router.navigateTo("/buy/" + post["id"]);
          };
        } else {
          module.div.getElementsByClassName("blockcoin")[0].remove();
          module.div.getElementsByClassName("a-blockcoin")[0].remove();
        }
        module.div.getElementsByClassName("username")[0].onclick = function () {
          if (buyer == null) {
            router.navigateTo("/profile/" + post["user-id"]);
          } else {
            router.navigateTo("/profile/" + buyer["id"]);
          }
        };
        var container = module.div.getElementsByClassName("post-badges-container")[0];
        var badges = ["award_star", "verified", "shield_person", "smart_toy", "local_fire_department", "science"];
        var titles = ["BlockCoin Admin", "Verified Account", "BlockCoin Staff", "Bot Account", "BlockCoin Premium", "Beta Tester"];
        for (var i = 0; i < buyer["badges"].length; i++) {
          var span = document.createElement("span");
          span.className = "material-symbols-outlined post-badge";
          span.innerHTML = badges[buyer["badges"][i]];
          span.title = titles[buyer["badges"][i]];
          // Append the span element to the container div
          container.appendChild(span);
        }
      });
    } else {
      var _liked = false;
      module.div.id = post["id"];
      if (buyer == null) {
        module.div.getElementsByClassName("username")[0].innerText = post["user"];
      } else {
        module.div.getElementsByClassName("username")[0].innerText = buyer["display"] + " original by " + post["user"];
      }
      var text = post["data"];
      text = text.replace(/>/g, '');
      text = text.replace(/</g, '');
      var htmlContent = marked.parse(text);
      module.div.getElementsByClassName("data")[0].innerHTML = htmlContent;
      module.div.getElementsByClassName("timestamp")[0].innerText = "BlockCoin Browser App - ".concat(timeConverter(post["date"]));
      if (buyer == null) {
        module.div.getElementsByClassName("profile-picture")[0].src = post["profile-picture"];
      } else {
        module.div.getElementsByClassName("profile-picture")[0].src = buyer["profile-picture"];
      }
      module.div.getElementsByClassName("views")[0].innerText = post["views"];
      module.div.getElementsByClassName("likes")[0].innerText = post["likes"];
      module.div.getElementsByClassName("blockcoin")[0].innerText = post["price"];
      module.div.getElementsByClassName("profile-picture")[0].onclick = function () {
        if (buyer == null) {
          router.navigateTo("/profile/" + post["user-id"]);
        } else {
          router.navigateTo("/profile/" + buyer["id"]);
        }
      };
      if (post["isBuyable"] == true) {
        module.div.getElementsByClassName("a-blockcoin")[0].onclick = function () {
          router.navigateTo("/buy/" + post["id"]);
        };
      } else {
        module.div.getElementsByClassName("blockcoin")[0].remove();
        module.div.getElementsByClassName("a-blockcoin")[0].remove();
      }
      module.div.getElementsByClassName("username")[0].onclick = function () {
        router.navigateTo("/profile/" + post["user-id"]);
      };
      var container = module.div.getElementsByClassName("post-badges-container")[0];
      var badges = ["award_star", "verified", "shield_person", "smart_toy", "local_fire_department", "science", 'bug_report'];
      var titles = ["BlockCoin Admin", "Verified Account", "BlockCoin Staff", "Bot Account", "BlockCoin Premium", "Beta Tester", "Bug Report"];
      for (var i = 0; i < post["badges"].length; i++) {
        var span = document.createElement("span");
        span.className = "material-symbols-outlined post-badge";
        span.innerHTML = badges[post["badges"][i]];
        span.title = titles[post["badges"][i]];
        // Append the span element to the container div
        container.appendChild(span);
      }
    }
    var liked = false;
    var sent_requests = false;
    function check_scroll() {
      var targetDiv = module.div;
      var bounding = targetDiv.getBoundingClientRect();

      // Checking if the div is in the viewport
      if (bounding.top >= 0 && bounding.left >= 0 && bounding.bottom <= (window.innerHeight || document.documentElement.clientHeight) && bounding.right <= (window.innerWidth || document.documentElement.clientWidth)) {
        if (IsLogedIn() && sent_requests == false) {
          sent_requests = true;
          ViewPost(post["id"]);
          PostLiked(post["id"]).then(function (data) {
            liked = data["liked"];
            if (data["liked"]) {
              module.div.getElementsByClassName("like-button")[0].classList.add('liked');
            }
          });
          module.div.getElementsByClassName("like-button")[0].onclick = function () {
            if (liked) {
              liked = false;
              module.div.getElementsByClassName("like-button")[0].classList.remove('liked');
              module.div.getElementsByClassName("likes")[0].innerText = parseInt(module.div.getElementsByClassName("likes")[0].innerText) - 1;
              LikePost(post["id"]);
            } else {
              liked = true;
              module.div.getElementsByClassName("like-button")[0].classList.add('liked');
              module.div.getElementsByClassName("likes")[0].innerText = parseInt(module.div.getElementsByClassName("likes")[0].innerText) + 1;
              LikePost(post["id"]);
            }
          };
        }
      }
    }
    check_scroll();
    window.addEventListener('scroll', function () {
      check_scroll();
    });
    module.div.getElementsByClassName("comment-button")[0].onclick = function () {
      router.navigateTo("/post/" + post["id"]);
    };
  }
  module.on_render(on_render);
  var element = document.getElementById(post["id"]);
  if (element == null) {
    module.render();
  } else {
    return "";
  }
}
function LivePost(router, post, parent) {
  var _require3 = require("../lib/Framework.mjs"),
    Module = _require3.Module;
  var module = new Module("Post");
  var blank_logo = module.image("logo_blank.svg");
  function timeConverter(UNIX_timestamp) {
    var a = new Date(UNIX_timestamp * 1000);
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var year = a.getFullYear();
    var month = months[a.getMonth()];
    var date = a.getDate();
    var hour = ('0' + a.getHours()).slice(-2); // Pad single-digit hours with leading zero
    var min = ('0' + a.getMinutes()).slice(-2); // Pad single-digit minutes with leading zero
    var sec = ('0' + a.getSeconds()).slice(-2); // Pad single-digit seconds with leading zero
    var time = date + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec;
    return time;
  }
  module.html("\n    <div id=\"post\">\n        <div id=\"top-container\">\n            <img id=\"post-img\" class=\"profile-picture\" class=\"text\"></img>\n            <div id=\"post-user\" class=\"text username\">Loading...</div>\n            <div class=\"post-badges-container\"></div>\n        </div>\n        <div id=\"post-data\" class=\"text data\">Loading...</div>\n        <div id=\"post-meta\" class=\"text timestamp\" >BlockCoin Browser App - Loading...</div>\n\n    </div>\n    ");
  module.css("\n    .like-button {\n        transition-duration: 0.5s;\n        cursor:pointer;\n    }\n    .like-button:hover {\n        font-size: 26px;\n    }\n    .liked {\n        color:#FF0000;\n        font-variation-settings:\n        'FILL' 1,\n        'wght' 400,\n        'GRAD' 0,\n        'opsz' 24\n    }\n    #post {\n        width:100%;\n        height: 100%;\n        top:0;\n        left:0;\n        border: solid white 1px;\n        border-radius: 16px\n    }\n    .post-badge {\n        font-size: 25px;\n        color: #FFFFFF;\n  \n      }\n      #post-badges-container {\n        width:20%;\n        display:flex;\n        flex-direction:row;\n        justify-content:flex-start;\n        align-items:center;\n        margin:10px;\n      }\n    .text {\n        font-family: 'Poppins', sans-serif;\n        font-weight: 400;\n        font-size: 25px;\n        color:white;\n    }\n\n    #post-img {\n        cursor:pointer;\n        border-radius:256px;\n        width: 48px;\n        height: 48px;\n        margin: 10px;\n    }\n\n    #post-user {\n        cursor:pointer;\n        margin: 10px;\n        margin-left:0;\n    }\n\n    #top-container {\n        position:relative;\n        top:0;\n        left:0;\n        width:100%;\n        height:fit-content;\n        display:flex;\n        justify-content: start;\n        align-items: center;\n        flex-direction: row;\n    \n    }\n\n    #post-meta {\n        margin: 10px;\n        font-weight: 300;\n        font-size: 17px;\n    }\n    #post-stats {\n        margin: 10px;\n        bottom:0;\n        position:relative;\n        right:0;\n        text-align:right;\n        font-weight: 300;\n        font-size: 17px;\n    }\n    #post-data {\n        margin: 10px;\n    }\n    ");
  module.parent(parent);
  function on_render() {
    var liked = false;
    module.div.id = post["id"];
    module.div.getElementsByClassName("username")[0].innerText = post["user"];
    var text = post["data"];
    text = text.replace(/>/g, '');
    text = text.replace(/</g, '');
    var htmlContent = marked.parse(text);
    module.div.getElementsByClassName("data")[0].innerHTML = htmlContent;
    module.div.getElementsByClassName("timestamp")[0].innerText = "BlockCoin Browser Live - ".concat(timeConverter(post["date"]));
    module.div.getElementsByClassName("profile-picture")[0].src = post["profile-picture"];
    module.div.getElementsByClassName("profile-picture")[0].onclick = function () {
      router.navigateTo("/profile/" + post["user-id"]);
    };
    module.div.getElementsByClassName("username")[0].onclick = function () {
      router.navigateTo("/profile/" + post["user-id"]);
    };
    var container = module.div.getElementsByClassName("post-badges-container")[0];
    var badges = ["award_star", "verified", "shield_person", "smart_toy", "local_fire_department", "science"];
    var titles = ["BlockCoin Admin", "Verified Account", "BlockCoin Staff", "Bot Account", "BlockCoin Premium", "Beta Tester"];
    for (var i = 0; i < post["badges"].length; i++) {
      var span = document.createElement("span");
      span.className = "material-symbols-outlined post-badge";
      span.innerHTML = badges[post["badges"][i]];
      span.title = titles[post["badges"][i]];
      // Append the span element to the container div
      container.appendChild(span);
    }
  }
  module.on_render(on_render);
  var element = document.getElementById(post["id"]);
  if (element == null) {
    module.render(true);
  } else {
    return "";
  }
}
function PreviewPost(router, post, parent) {
  var _require4 = require("../lib/Framework.mjs"),
    Module = _require4.Module;
  var _require5 = require("../scripts/api.mjs"),
    ViewPost = _require5.ViewPost,
    IsLogedIn = _require5.IsLogedIn,
    PostLiked = _require5.PostLiked,
    LikePost = _require5.LikePost;
  var module = new Module("Post");
  var blank_logo = module.image("logo_blank.svg");
  function timeConverter(UNIX_timestamp) {
    var a = new Date(UNIX_timestamp * 1000);
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var year = a.getFullYear();
    var month = months[a.getMonth()];
    var date = a.getDate();
    var hour = ('0' + a.getHours()).slice(-2); // Pad single-digit hours with leading zero
    var min = ('0' + a.getMinutes()).slice(-2); // Pad single-digit minutes with leading zero
    var sec = ('0' + a.getSeconds()).slice(-2); // Pad single-digit seconds with leading zero
    var time = date + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec;
    return time;
  }
  module.html("\n    <div id=\"post\">\n        <div id=\"top-container\">\n            <img id=\"post-img\" class=\"profile-picture\" class=\"text\"></img>\n            <div id=\"post-user\" class=\"text username\">Loading...</div>\n        </div>\n        <div id=\"post-data\" class=\"text data\">Loading...</div>\n    </div>\n    ");
  module.css("\n    .a-blockcoin {\n        width:24px;\n        height:24px;\n    }\n    .like-button {\n        transition-duration: 0.5s;\n        cursor:pointer;\n    }\n    .like-button:hover {\n        font-size: 26px;\n    }\n    .a-blockcoin:hover {\n        transition-duration: 0.5s;\n        cursor:pointer;\n        width:26px;\n        height:26px;\n    }\n    .liked {\n        color:#FF0000;\n        font-variation-settings:\n        'FILL' 1,\n        'wght' 400,\n        'GRAD' 0,\n        'opsz' 24\n    }\n    #post {\n        width:100%;\n        height: 100%;\n        top:0;\n        left:0;\n        border: solid white 1px;\n        border-radius: 16px\n    }\n    .post-badge {\n        font-size: 25px;\n        color: #FFFFFF;\n  \n      }\n      #post-badges-container {\n        width:20%;\n        display:flex;\n        flex-direction:row;\n        justify-content:flex-start;\n        align-items:center;\n        margin:10px;\n      }\n    .text {\n        font-family: 'Poppins', sans-serif;\n        font-weight: 400;\n        font-size: 25px;\n        color:white;\n    }\n\n    #post-img {\n        cursor:pointer;\n        border-radius:256px;\n        width: 48px;\n        height: 48px;\n        margin: 10px;\n    }\n\n    #post-user {\n        cursor:pointer;\n        margin: 10px;\n        margin-left:0;\n    }\n\n    #top-container {\n        position:relative;\n        top:0;\n        left:0;\n        width:100%;\n        height:fit-content;\n        display:flex;\n        justify-content: start;\n        align-items: center;\n        flex-direction: row;\n    \n    }\n\n    #post-meta {\n        margin: 10px;\n        font-weight: 300;\n        font-size: 17px;\n    }\n    #post-stats {\n        margin: 10px;\n        bottom:0;\n        position:relative;\n        right:0;\n        text-align:right;\n        font-weight: 300;\n        font-size: 17px;\n    }\n    #post-data {\n        margin: 10px;\n    }\n    ");
  module.parent(parent);
  function on_render() {
    var liked = false;
    module.div.id = post["id"];
    module.div.getElementsByClassName("username")[0].innerText = post["user"];
    var text = post["data"];
    text = text.replace(/>/g, '');
    text = text.replace(/</g, '');
    var htmlContent = marked.parse(text);
    module.div.getElementsByClassName("data")[0].innerHTML = htmlContent;
    module.div.getElementsByClassName("profile-picture")[0].src = post["profile-picture"];
  }
  module.on_render(on_render);
  var element = document.getElementById(post["id"]);
  if (element == null) {
    module.render();
  } else {
    return "";
  }
}

},{"../lib/Framework.mjs":10,"../scripts/api.mjs":29}],10:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Theme = exports.Router = exports.Page = exports.Module = exports.Display = void 0;
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : String(i); }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
var pages = {};
var themes = {};
var current_theme;
var CanNavigate = true;
function SwitchCanNavigate(newdata) {
  CanNavigate = newdata;
}
var Theme = exports.Theme = /*#__PURE__*/function () {
  function Theme(name) {
    _classCallCheck(this, Theme);
    this.name = name;
    this.type = "json";
    this.data = {};
  }
  _createClass(Theme, [{
    key: "propertie",
    value: function propertie(name, value) {
      this.data[name] = value;
    }
  }, {
    key: "get",
    value: function get(name) {
      if (this.type == "json" || this.type == undefined) {
        var data = this.data[name];
        return data;
      }
    }
  }, {
    key: "parse",
    value: function parse(json) {
      var meta = json.meta;
      this.type = meta.type;
      if (this.type == "json" || this.type == undefined) {
        for (var key in json.data) {
          var childKey = key;
          var childValue = json.data[key];
          this.propertie(childKey, childValue);
        }
      } else {
        var cssString = '';
        console.log("css");
        for (var _key in json.data) {
          if (Object.hasOwnProperty.call(json.data, _key)) {
            var element = json.data[_key];
            var elementType = ".";
            if (element["type"] == "tag") {
              elementType = "";
            } else if (element["type"] == "class") {
              elementType = ".";
            } else {
              elementType = "#";
            }
            cssString += "".concat(elementType).concat(_key, " {");
            delete element['type'];
            for (var styleKey in element) {
              if (Object.hasOwnProperty.call(element, styleKey)) {
                cssString += "".concat(styleKey, ": ").concat(element[styleKey], " !important;");
              }
            }
            cssString += "}\n";
          }
        }
        var styleTag = document.createElement('style');
        styleTag.textContent = cssString;
        document.head.appendChild(styleTag);
      }
    }
  }, {
    key: "register",
    value: function register() {
      themes[this.name] = this;
    }
  }]);
  return Theme;
}();
var Display = exports.Display = /*#__PURE__*/function () {
  function Display() {
    _classCallCheck(this, Display);
  }
  _createClass(Display, [{
    key: "set_theme",
    value: function set_theme(name) {
      current_theme = name;
    }
  }, {
    key: "get",
    value: function get(name) {
      var theme_data = themes[current_theme].get(name);
      if (theme_data == undefined) {
        console.log("Default", name, themes["default"].get(name));
        return themes["default"].get(name);
      } else {
        console.log("Theme", name, theme_data);
        return theme_data;
      }
    }
  }]);
  return Display;
}();
var Page = exports.Page = /*#__PURE__*/function () {
  function Page(route) {
    _classCallCheck(this, Page);
    this.route = route;
    this.document;
    this.on_delete_func;
    pages[this.route.toLowerCase()] = this;
  }
  _createClass(Page, [{
    key: "html",
    value: function html(code) {
      this.html = code;
    }
  }, {
    key: "css",
    value: function css(code) {
      this.css = code;
    }
  }, {
    key: "delete_animation",
    value: function delete_animation(code) {
      this.delete_anim = code;
    }
  }, {
    key: "spawn_animation",
    value: function spawn_animation(code) {
      this.create_anim = code;
    }
  }, {
    key: "image",
    value: function image(path) {
      return "https://blockcoin.social/assets/" + path;
    }
  }, {
    key: "spawn",
    value: function spawn() {
      if (this.create_anim !== undefined) {
        var newStyle = document.createElement("style");
        newStyle.innerHTML = this.create_anim;
        this.document.appendChild(newStyle);
        var _iterator = _createForOfIteratorHelper(this.document.children),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var child = _step.value;
            if (child.tagName.toLowerCase() == 'div') {
              child.style.animation = 'spawn 1s';
            }
          }
        } catch (err) {
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
      }
    }
  }, {
    key: "on_delete",
    value: function on_delete(func) {
      this.on_delete_func = func;
    }
  }, {
    key: "delete",
    value: function _delete() {
      try {
        if (typeof this.on_delete_func == "function") {
          this.on_delete_func();
        }
      } catch (e) {
        console.log("Error", e.stack);
        console.log("Error", e.name);
        console.log("Error", e.message);
      }
      pages[this.route.toLowerCase()] = undefined;
    }
  }, {
    key: "clear",
    value: function clear(except) {
      var elems = document.body.children;
      if (!Array.isArray(except)) {
        except = [];
      }
      except.push("noscript");
      except.push("script");
      except.push("div");
      except.push("style");
      except.push("notification");
      var index = except.indexOf("navbar");
      if (index > -1) {
        except.splice(index, 1);
      }
      var bodyChildren = document.body.children;
      for (var i = bodyChildren.length - 1; i >= 0; i--) {
        var child = bodyChildren[i];
        if (except.indexOf(child.tagName.toLowerCase()) === -1) {
          if (pages[child.tagName.toLowerCase()] != undefined) {
            try {
              pages[child.tagName.toLowerCase()]["delete"]();
              document.body.removeChild(child);
            } catch (_unused) {
              document.body.removeChild(child);
            }
          } else {
            document.body.removeChild(child);
          }
        }
      }
    }
  }, {
    key: "on_render",
    value: function on_render(func) {
      this.on = func;
    }
  }, {
    key: "render",
    value: function render() {
      if (document.getElementsByTagName(this.route.toLowerCase()).length == 0) {
        var newDiv = document.createElement(this.route.toLowerCase());
        newDiv.innerHTML = this.html;
        document.body.appendChild(newDiv);
        var newStyle = document.createElement("style");
        newStyle.innerHTML = this.css;
        newDiv.appendChild(newStyle);
        this.document = newDiv;
        this.spawn();
        pages[this.route.toLowerCase()] = this;
        try {
          if (typeof this.on == "function") {
            this.on();
          }
        } catch (e) {
          console.log("Error", e.stack);
          console.log("Error", e.name);
          console.log("Error", e.message);
        }
      }
    }
  }]);
  return Page;
}();
var Router = exports.Router = /*#__PURE__*/function () {
  function Router() {
    _classCallCheck(this, Router);
    this.routes = {};
    this.errors = {};
  }
  _createClass(Router, [{
    key: "registerRoute",
    value: function registerRoute(endpoint, filePath) {
      this.routes[endpoint] = filePath;
    }
  }, {
    key: "registerError",
    value: function registerError(error, filePath) {
      this.errors[error] = filePath;
    }
  }, {
    key: "navigateError",
    value: function navigateError(code) {
      if (CanNavigate == false) {
        return "";
      }
      var functionpage = this.errors[code];
      history.pushState({}, null, "/" + code);
      if (functionpage) {
        try {
          if (typeof functionpage === 'function') {
            functionpage(this);
          } else {
            for (var i in functionpage) {
              functionpage[i](this);
            }
          }
        } catch (error) {
          console.error("Error loading module for code ".concat(code, ":"), error);
        }
      } else {
        console.error("No handler registered for error: ".concat(code));
      }
    }
  }, {
    key: "navigateTo",
    value: function navigateTo(endpoint, first) {
      if (CanNavigate == false) {
        return "";
      }
      if (window.location.pathname == endpoint && first != 1) {
        return "";
      }
      var route = endpoint.split("/")[1];
      history.pushState({}, null, endpoint);
      var functionpage = this.routes[route];
      if (functionpage) {
        try {
          if (typeof functionpage === 'function') {
            functionpage(this);
          } else {
            for (var i in functionpage) {
              functionpage[i](this);
            }
          }
        } catch (error) {
          console.error("Error loading module for endpoint ".concat(endpoint, ":"), error);
        }
      } else {
        this.navigateError(404);
        console.error("No handler registered for endpoint: ".concat(endpoint));
      }
    }
  }, {
    key: "start",
    value: function start() {
      var currentEndpoint = window.location.pathname;
      this.navigateTo(currentEndpoint, 1);
    }
  }]);
  return Router;
}();
var Module = exports.Module = /*#__PURE__*/function () {
  function Module(name, parent) {
    _classCallCheck(this, Module);
    this.name = name;
    this.parent_div = parent;
    this.div;
  }
  _createClass(Module, [{
    key: "html",
    value: function html(code) {
      this.html = code;
    }
  }, {
    key: "css",
    value: function css(code) {
      this.css = code;
    }
  }, {
    key: "parent",
    value: function parent(html) {
      this.parent_div = html;
    }
  }, {
    key: "delete_animation",
    value: function delete_animation(code) {
      this.delete_anim = code;
    }
  }, {
    key: "spawn_animation",
    value: function spawn_animation(code) {
      this.create_anim = code;
    }
  }, {
    key: "image",
    value: function image(path) {
      return "https://blockcoin.social/assets/" + path;
    }
  }, {
    key: "on_render",
    value: function on_render(func) {
      this.on = func;
    }
  }, {
    key: "delete",
    value: function _delete() {
      var newStyle = document.createElement("style");
      newStyle.innerHTML = this.delete_anim;
      this.div.appendChild(newStyle);
      this.div.style.animation = 'delete 1s';
      if (this.delete_anim == undefined) {
        this.div.remove();
        return "";
      }
      var self = this;
      var handler = function handler() {
        self.div.removeEventListener("animationend", handler, false);
        self.div.remove();
      };
      self.div.addEventListener("animationend", handler, false);
    }
  }, {
    key: "spawn",
    value: function spawn() {
      var newStyle = document.createElement("style");
      newStyle.innerHTML = this.create_anim;
      this.div.appendChild(newStyle);
      this.div.style.animation = 'spawn 1s';
    }
  }, {
    key: "render",
    value: function render(first) {
      var newDiv = document.createElement(this.name.toLowerCase());
      newDiv.innerHTML = this.html;
      console.log(first);
      if (first == true && this.parent_div.firstChild !== null) {
        this.parent_div.insertBefore(newDiv, this.parent_div.firstChild);
      } else {
        this.parent_div.appendChild(newDiv);
      }
      var newStyle = document.createElement("style");
      newStyle.innerHTML = this.css;
      newDiv.appendChild(newStyle);
      this.div = newDiv;
      this.spawn();
      if (typeof this.on == "function") {
        this.on();
      }
    }
  }]);
  return Module;
}();

},{}],11:[function(require,module,exports){
"use strict";

var _require = require("./lib/Framework.mjs"),
  Router = _require.Router,
  Theme = _require.Theme,
  Display = _require.Display;
var _require2 = require("./pages/landing.mjs"),
  Landing = _require2.Landing;
var _require3 = require("./pages/login.mjs"),
  Login = _require3.Login;
var _require4 = require("./pages/register.mjs"),
  Register = _require4.Register;
var _require5 = require("./pages/errors.mjs"),
  NotFound = _require5.NotFound;
var _require6 = require("./pages/redirect.mjs"),
  Redirect = _require6.Redirect;
var _require7 = require("./pages/trending.mjs"),
  Trending = _require7.Trending;
var _require8 = require("./pages/feed.mjs"),
  Feed = _require8.Feed;
var _require9 = require("./pages/new_post.mjs"),
  NewPost = _require9.NewPost;
var _require10 = require("./pages/new_comment.mjs"),
  NewComment = _require10.NewComment;
var _require11 = require("./pages/profile.mjs"),
  Profile = _require11.Profile;
var _require12 = require("./pages/dashboard.mjs"),
  Dashboard = _require12.Dashboard;
var _require13 = require("./pages/settings.mjs"),
  Settings = _require13.Settings;
var _require14 = require("./pages/explore.mjs"),
  Explore = _require14.Explore;
var _require15 = require("./pages/live.mjs"),
  Live = _require15.Live;
var _require16 = require("./pages/maintenance.mjs"),
  Maintenance = _require16.Maintenance;
var _require17 = require("./pages/buy.mjs"),
  Buy = _require17.Buy;
var _require18 = require("./scripts/api.mjs"),
  VerifyToken = _require18.VerifyToken,
  IsLogedIn = _require18.IsLogedIn;
var _require19 = require("./scripts/cookies.mjs"),
  setCookie = _require19.setCookie,
  getCookie = _require19.getCookie,
  checkCookie = _require19.checkCookie;
var _require20 = require("./pages/post.mjs"),
  Post = _require20.Post;
var router = new Router();
var maintenance = false;
if (maintenance == false) {
  //Pages
  router.registerRoute("", [Landing]);
  router.registerRoute("login", [Login]);
  router.registerRoute("register", [Register]);
  router.registerRoute("trending", [Trending]);
  router.registerRoute("feed", [Feed]);
  router.registerRoute("new", [NewPost]);
  router.registerRoute("profile", [Profile]);
  router.registerRoute("dashboard", [Dashboard]);
  router.registerRoute("settings", [Settings]);
  router.registerRoute("explore", [Explore]);
  router.registerRoute("live", [Live]);
  router.registerRoute("buy", [Buy]);
  router.registerRoute("post", [Post]);
  router.registerRoute("comment", [NewComment]);

  //Errors
  router.registerError(404, [NotFound]);

  //Redirections
  router.registerRoute("status", [Redirect]);
  router.registerRoute("twitter", [Redirect]);
  router.registerRoute("discord", [Redirect]);
  router.registerRoute("scratch", [Redirect]);
  router.registerRoute("api", [Redirect]);
  router.registerRoute("docs", [Redirect]);
} else {
  router.registerRoute("", [Maintenance]);
  router.registerError(404, [Maintenance]);
  router.registerRoute("discord", [Redirect]);
}
var defaultTheme = new Theme("default");
var defaultJson = require('./themes/default.json');
defaultTheme.parse(defaultJson);
defaultTheme.register();
var display = new Display();
if (getCookie("v1-theme")) {
  var parsedData = JSON.parse(getCookie("v1-theme"));
  var customTheme = new Theme("custom");
  customTheme.parse(parsedData);
  customTheme.register();
  display.set_theme("custom");
} else {
  display.set_theme("default");
}
router.start();
if (IsLogedIn()) {
  VerifyToken().then(function (value) {
    if (value != true) {
      setCookie("v1-user", "");
      setCookie("v1-id", "");
      setCookie("v1-token", "");
      setCookie("v1-profile-picture", "");
      router.navigateTo("/");
    }
  });
}

},{"./lib/Framework.mjs":10,"./pages/buy.mjs":12,"./pages/dashboard.mjs":13,"./pages/errors.mjs":14,"./pages/explore.mjs":15,"./pages/feed.mjs":16,"./pages/landing.mjs":17,"./pages/live.mjs":18,"./pages/login.mjs":19,"./pages/maintenance.mjs":20,"./pages/new_comment.mjs":21,"./pages/new_post.mjs":22,"./pages/post.mjs":23,"./pages/profile.mjs":24,"./pages/redirect.mjs":25,"./pages/register.mjs":26,"./pages/settings.mjs":27,"./pages/trending.mjs":28,"./scripts/api.mjs":29,"./scripts/cookies.mjs":30,"./themes/default.json":31}],12:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Buy = Buy;
function Buy(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page,
    Display = _require.Display;
  var _require2 = require("../elements/fonts.mjs"),
    Fonts = _require2.Fonts;
  var _require3 = require("../elements/background.mjs"),
    Background = _require3.Background;
  var _require4 = require("../elements/navbar.mjs"),
    Navbar = _require4.Navbar;
  var _require5 = require("../scripts/api.mjs"),
    IsLogedIn = _require5.IsLogedIn,
    Balance = _require5.Balance,
    Stats = _require5.Stats,
    BuyPost = _require5.BuyPost;
  var _require6 = require("../elements/notifications.mjs"),
    Notification = _require6.Notification;
  var _require7 = require("../scripts/cookies.mjs"),
    setCookie = _require7.setCookie,
    getCookie = _require7.getCookie,
    checkCookie = _require7.checkCookie;
  var _require8 = require("../elements/post.mjs"),
    PreviewPost = _require8.PreviewPost;
  if (IsLogedIn() == false) {
    Notification(1, "You need to be logged in to access this page.");
    router.navigateTo("/explore");
    return "";
  }
  var page = new Page("Buy");
  var display = new Display();
  page.clear(["background", "navbar", "fonts", "new_post_button"]);
  Fonts(router);
  Background(router);
  Navbar(router);
  var blank_logo = page.image("logo_blank.svg");
  page.html("\n      <div id=\"big-container\">\n        <div id=\"container\">\n          <div id=\"cont-1\" class=\"container\">\n            <div class=\"title\" id=\"title\">\n              Overwiew Post #Loading... by @Loading...\n            </div>\n          </div>\n          <div id=\"cont-2\" class=\"container\">\n            <div class=\"title\">\n              Preview\n            </div>\n            <div id=\"post-container-buy\"></div>\n          </div>\n          <div id=\"cont-3\" class=\"container\">\n          <div class=\"title\">\n            Stats\n          </div>\n          <div id=\"stats-container\">\n            <div class=\"stat\"><span class=\"material-symbols-outlined\" id=\"icon-1\">favorite</span> <span id=\"likes\">0</span> </div>\n            <div class=\"stat\"><span class=\"material-symbols-outlined\" id=\"icon-2\">visibility</span> <span id=\"views\">0</span> </div>\n            <div class=\"stat\"><img src=\"".concat(blank_logo, "\" class=\"a-stat-blockcoin\" /> <span id=\"blockcoin\">0</span>  </div>\n          </div>\n          </div>\n          <div id=\"cont-4\" class=\"container\">\n            <div id=\"buy\">Buy Post #Loading.. ?</div>\n            <div id=\"buy-button\"><span id=\"buy-text\">Buy - 15 </span><img src=\"").concat(blank_logo, "\" class=\"a-stat-button\" /></div>\n          </div>\n          <div id=\"cont-5\" class=\"container\">\n            <canvas id=\"canva-data\"></canvas>\n          </div>\n        </div>\n      </div>\n      \n    "));
  page.css("\n    .a-stat-blockcoin {\n      width:50px;\n      height:50px;\n      \n    }\n    .a-stat-button {\n      width:37px;\n      height:37px;\n      margin-left:17px;\n    }\n    #buy {\n      font-family: '".concat(display.get("text")["font"], "', sans-serif;\n      font-weight: 500;\n      font-size: ").concat(display.get("text")["size"][1], ";\n      text-align:center;\n      color: ").concat(display.get("text")["color"], ";\n    }\n    #buy-button {\n      cursor:pointer;\n      transition-duration: 0.5s;\n      font-family: '").concat(display.get("text")["font"], "', sans-serif;\n      font-weight: 400;\n      font-size: ").concat(display.get("text")["size"][2], ";\n      color: ").concat(display.get("text")["color"], ";\n      border-radius: ").concat(display.get("global")["border-radius"][0], ";\n      border: ").concat(display.get("global")["border"], ";\n      height:auto;\n      width:auto;\n      text-align:center;\n      display:flex;\n      align-items:center;\n      justify-content:center;\n    }\n    #post-container-buy post {\n      width:80%;\n      height:fit-content;\n      min-height: 5%;\n    }\n    #post-container-buy {\n      overflow:auto;\n      display: flex;\n      justify-content:center;\n      align-items:center;\n      top:20%;\n      height:80%;\n      width:100%;\n      left:0;\n      position:absolute;\n    }\n    #canva-data{\n      width:100%;\n      height:100%;\n    } \n    .link {\n      cursor:pointer;\n      border: ").concat(display.get("global")["border"], ";\n      width: 20%;\n      height: 40%;\n      font-size: ").concat(display.get("text")["size"][2], ";\n      color: ").concat(display.get("text")["color"], ";\n      font-family: '").concat(display.get("text")["font"], "', sans-serif;\n      font-weight: 400;\n      text-align:center;\n      border-radius: ").concat(display.get("global")["border-radius"][0], ";\n      margin:5%;\n      margin-top:0;\n      margin-bottom:0;\n      display: flex;\n      justify-content:center;\n      align-items:center;\n    }\n    #links-container {\n      display: flex;\n      flex-wrap: wrap;\n      width:100%;\n      height:70%;\n      position:absolute;\n      top:25%;\n      left:0;\n      justify-content:center;\n      align-items:center;\n    }\n    #lb-container {\n      display:flex;\n      justify-content:space-evenly;\n      position:absolute;\n      left:0;\n      flex-direction:row;\n      width:100%;\n      height:70%;\n      top:20%;\n      align-items:center;\n    }\n    .lb {\n      font-size: ").concat(display.get("text")["size"][2], ";\n      color: ").concat(display.get("text")["color"], ";\n      font-family: '").concat(display.get("text")["font"], "', sans-serif;\n      font-weight: 400;\n      text-align:center;\n    }\n    .lb-big {\n      font-size: ").concat(display.get("text")["size"][4], ";\n    }\n    #stats {\n      font-size: ").concat(display.get("text")["size"][4], ";\n    }\n    #icon-1 {\n      font-size: ").concat(display.get("text")["size"][4], ";\n    }\n    #icon-2 {\n      font-size: ").concat(display.get("text")["size"][4], ";\n    }\n    #icon-3 {\n      font-size: ").concat(display.get("text")["size"][4], ";\n    }\n    #icon-4 {\n      font-size: ").concat(display.get("text")["size"][4], ";\n    }\n    .stat {\n      font-size: ").concat(display.get("text")["size"][4], ";\n      color: ").concat(display.get("text")["color"], ";\n      font-family: '").concat(display.get("text")["font"], "', sans-serif;\n      font-weight: 400;\n    }\n    #stats-container {\n      display:flex;\n      justify-content:center;\n      position:absolute;\n      top:0;\n      left:0;\n      flex-direction:column;\n      width:100%;\n      height:70%;\n      top:20%;\n      align-items:center;\n    }\n    #welcome {\n      font-family: '").concat(display.get("text")["font"], "', sans-serif;\n      font-weight: 400;\n      color: ").concat(display.get("text")["color"], ";\n      font-size: ").concat(display.get("text")["size"][2], ";\n      margin-left:5px;\n    }\n    #balance {\n      font-family: '").concat(display.get("text")["font"], "', sans-serif;\n      font-weight: 500;\n      color: ").concat(display.get("text")["color"], ";\n      font-size: ").concat(display.get("text")["size"][4], ";\n      display:flex;\n      justify-content:flex-end;\n      align-items:center;\n      margin-left:2.5%;\n      margin-right:22px;\n    }\n    #cont-1-5 {\n      position:absolute;\n      display:flex;\n      justify-content:flex-start;\n      align-items:center;\n      top:5%;\n      left:2.5%;\n      width:50%;\n    }\n    #cont-1-8 {\n      position:absolute;\n      display:flex;\n      justify-content:flex-start;\n      align-items:center;\n      top:0;\n      left:0;\n      width:100%;\n      height:100%;\n    }\n    #balance img {\n      width:75px;\n      height:75px;\n    }\n    .title {\n      font-family: '").concat(display.get("text")["font"], "', sans-serif;\n      font-weight: 400;\n      color: ").concat(display.get("text")["color"], ";\n      font-size: ").concat(display.get("text")["size"][3], ";\n      text-align:center;\n      position:absolute;\n      top:5%;\n      left:2.5%;\n    }\n    #big-container {\n      width:100%;\n      height:100%;\n      display:flex;\n      justify-content:center;\n      align-items:center;\n      position:absolute;\n      top:0;\n      left:0;\n    }\n    #container {\n      width:80%;\n      height:80%;\n    }\n    .container {\n      border: ").concat(display.get("global")["border"], ";\n      border-radius: ").concat(display.get("global")["border-radius"][0], ";\n      position:absolute;\n    }\n    #cont-1{\n      width:80%;\n      height:15%;\n      top:15%;\n      left:10%;\n      display: flex;\n      justify-content:center;\n      align-items:center;\n    }\n\n    #cont-1 div{\n      width:100%;\n      position:static;\n      margin:none;\n    }\n\n    #cont-1 img{\n      width:65px;\n      border-radius:256px;\n      height:65px;\n    }\n\n    #cont-2{\n      width:39.75%;\n      height:29%;\n      top:31%;\n      left:10%;\n    }\n    #cont-3{\n      width:39.75%;\n      height:29%;\n      top:31%;\n      right:10%;\n    }\n    #cont-4{\n      width:19.75%;\n      height:35%;\n      right:10%;\n      top:61%;\n      display:flex;\n      align-items:center;\n      justify-content: space-around;\n      flex-direction:column;\n    }\n    #cont-5{\n      width:59.75%;\n      height:35%;\n      left:10%;\n      top:61%;\n    }\n  "));
  function on_render() {
    var api_url = "wss://api.blockcoin.social";
    if (window.location.hostname == "127.0.0.1" || window.location.hostname == "localhost") {
      api_url = "ws://127.0.0.1:8080";
    }
    var socket = null;
    var cache = null;
    var post_id = window.location.pathname.split("/")[2];
    socket = new WebSocket(api_url + '/post');
    socket.addEventListener('message', function (event) {
      var data = JSON.parse(event.data);
      cache = data;
    });
    function waitForNonNullCache() {
      var interval = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 100;
      return new Promise(function (resolve) {
        function checkVariable() {
          cache;
          if (cache !== null) {
            resolve(cache);
          } else {
            setTimeout(checkVariable, interval);
          }
        }
        checkVariable();
      });
    }
    socket.addEventListener('open', function (event) {
      socket.send(JSON.stringify({
        'opcode': 1,
        "id": post_id
      }));
    });
    waitForNonNullCache().then(function (value) {
      var post = value;
      if (value["success"] != true) {
        Notification(1, "Unknown Post");
        router.navigateTo("/explore");
        return "";
      }
      document.getElementById("title").innerText = "Overwiew Post #" + post["data"]["id"] + " by @" + post["profile"]["display"];
      document.getElementById("buy").innerText = "Buy post #" + post["data"]["id"] + " ?";
      document.getElementById("buy-text").innerText = "Buy - " + post["data"]["price"];
      document.getElementById("likes").innerText = post["data"]["likes"];
      document.getElementById("views").innerText = post["data"]["views"];
      document.getElementById("blockcoin").innerText = post["data"]["price"];
      document.getElementById("buy-button").onclick = function () {
        grecaptcha.ready(function () {
          grecaptcha.execute('6Lf1n4IoAAAAAEXFEel1BfkxHrcuzJUJNfPiFA3q', {
            action: 'submit'
          }).then(function (token) {
            BuyPost(post_id, token).then(function (value) {
              if (value == true) {
                Notification(0, "Post Buyed ;)");
                router.navigateTo("/explore");
                return "";
              } else {
                Notification(1, value);
              }
            });
          });
        });
      };
      if (post["data"]["isBuyable"] == false) {
        Notification(1, "This post is not to sell.");
        router.navigateTo("/explore");
        return "";
      }
      var post_data = post["data"];
      post_data["user-id"] = post["profile"]["id"];
      post_data["user"] = post["profile"]["display"];
      post_data["profile-picture"] = post["profile"]["profile-picture"];
      post_data["badges"] = post["profile"]["badges"];
      var new_post = new PreviewPost(router, post_data, document.getElementById("post-container-buy"));
      var posts = value["data"]["chart"];
      console.log(posts);
      console.log(value);
      // Sort the posts based on the time
      posts.sort(function (a, b) {
        return a["time"] - b["time"];
      });

      // Initialize arrays for datasets
      var timeLabels = [];
      var viewPerDay = [];
      var totalViews = [];
      var likePerDay = [];
      var totalLikes = [];
      var priceChangePerDay = [];
      var totalPrice = [];

      // Calculate daily changes and total values
      if (posts.length > 1) {
        for (var i = 1; i < posts.length; i++) {
          var timeDiff = posts[i]["time"] - posts[i - 1]["time"];
          timeLabels.push(new Date(posts[i]["time"] * 1000).toLocaleDateString()); // Convert time to date format
          viewPerDay.push((posts[i]["view"] - posts[i - 1]["view"]) / (timeDiff / 86400)); // Calculate views per day
          totalViews.push(posts[i]["view"]); // Add total views
          likePerDay.push((posts[i]["like"] - posts[i - 1]["like"]) / (timeDiff / 86400)); // Calculate likes per day
          totalLikes.push(posts[i]["like"]); // Add total likes
          priceChangePerDay.push((posts[i]["price"] - posts[i - 1]["price"]) / (timeDiff / 86400)); // Calculate price change per day
          totalPrice.push(posts[i]["price"]); // Add total price
        }
      } else {
        // If there's only one timestamp, display total values without evolution
        timeLabels.push(new Date(posts[0]["time"] * 1000).toLocaleDateString());
        totalViews.push(posts[0]["view"]);
        totalLikes.push(posts[0]["like"]);
        totalPrice.push(posts[0]["price"]);
      }
      console.log(timeLabels);
      console.log(viewPerDay);
      console.log(totalViews);
      console.log(likePerDay);
      console.log(totalLikes);
      console.log(priceChangePerDay);
      console.log(totalPrice);
      // Create the chart
      var ctx = document.getElementById('canva-data').getContext('2d');
      var myChart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: timeLabels,
          datasets: [{
            label: 'Views per day',
            data: viewPerDay,
            borderColor: 'blue',
            backgroundColor: 'lightblue'
          }, {
            label: 'Total Views',
            data: totalViews,
            borderColor: 'green',
            backgroundColor: 'lightgreen'
          }, {
            label: 'Likes per day',
            data: likePerDay,
            borderColor: 'red',
            backgroundColor: 'pink'
          }, {
            label: 'Total Likes',
            data: totalLikes,
            borderColor: 'orange',
            backgroundColor: 'yellow'
          }, {
            label: 'Price change per day',
            data: priceChangePerDay,
            borderColor: 'purple',
            backgroundColor: 'lavender'
          }, {
            label: 'Total Price',
            data: totalPrice,
            borderColor: 'brown',
            backgroundColor: 'tan'
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false
        }
      });
    });
  }
  page.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.on_render(on_render);
  page.render();
}

},{"../elements/background.mjs":2,"../elements/fonts.mjs":4,"../elements/navbar.mjs":6,"../elements/notifications.mjs":8,"../elements/post.mjs":9,"../lib/Framework.mjs":10,"../scripts/api.mjs":29,"../scripts/cookies.mjs":30}],13:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Dashboard = Dashboard;
function Dashboard(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page,
    Display = _require.Display;
  var _require2 = require("../elements/fonts.mjs"),
    Fonts = _require2.Fonts;
  var _require3 = require("../elements/background.mjs"),
    Background = _require3.Background;
  var _require4 = require("../elements/navbar.mjs"),
    Navbar = _require4.Navbar;
  var _require5 = require("../scripts/api.mjs"),
    IsLogedIn = _require5.IsLogedIn,
    Balance = _require5.Balance,
    Stats = _require5.Stats;
  var _require6 = require("../elements/notifications.mjs"),
    Notification = _require6.Notification;
  var _require7 = require("../scripts/cookies.mjs"),
    setCookie = _require7.setCookie,
    getCookie = _require7.getCookie,
    checkCookie = _require7.checkCookie;
  if (IsLogedIn() == false) {
    Notification(1, "You need to be logged in to access this page.");
    router.navigateTo("/explore");
    return "";
  }
  var page = new Page("Dashboard");
  var display = new Display();
  page.clear(["background", "navbar", "fonts", "new_post_button"]);
  Fonts(router);
  Background(router);
  Navbar(router);
  var blank_logo = page.image("logo_blank.svg");
  page.html("\n      <div id=\"big-container\">\n        <div id=\"container\">\n          <div id=\"cont-1\" class=\"container\">\n            <div id=\"cont-1-5\">\n              <img id=\"dash-profile-picture\" />\n              <div id=\"welcome\"> Welcome back Loading.</div>\n            </div>\n            <div id=\"cont-1-8\">\n              <div id=\"balance\">Balance: 0</div> \n              <img src=\"".concat(blank_logo, "\" alt=\"A white version of the blockcoin logo.\" id=\"currency\"/>\n            </div>\n          </div>\n          <div id=\"cont-2\" class=\"container\">\n            <div id=\"stats\" class=\"title\">Stats</div>\n            <div id=\"stats-container\">\n              <div class=\"stat\"><span class=\"material-symbols-outlined\" id=\"icon-1\">favorite</span> <span id=\"likes\">0</span> </div>\n              <div class=\"stat\"><span class=\"material-symbols-outlined\" id=\"icon-2\">visibility</span> <span id=\"views\">0</span> </div>\n              <div class=\"stat\"><span class=\"material-symbols-outlined\" id=\"icon-3\">comment</span> <span id=\"comments\">0</span> </div>\n              <div class=\"stat\"><span class=\"material-symbols-outlined\" id=\"icon-4\">sync</span> <span id=\"reposts\">0</span> </div>\n            </div>\n          </div>\n          <div id=\"cont-3\" class=\"container\">\n            <div class=\"title\">Leaderboards</div>\n            <div id=\"lb-container\">\n              <div class=\"lb\"><span id=\"lb-balance\" class=\"lb-big\">#0</span><br>Total Balance</div>\n              <div class=\"lb\"><span id=\"lb-views\" class=\"lb-big\">#0</span><br>Total Views</div>\n              <div class=\"lb\"><span id=\"lb-likes\" class=\"lb-big\">#0</span><br>Total Likes</div>\n            </div>\n          </div>\n          <div id=\"cont-4\" class=\"container\">\n            <div class=\"title\">Quick Links</div>  \n            <div id=\"links-container\">\n              <div class=\"link\" id=\"link-settings\"><p>Settings</p></div>\n              <div class=\"link\" id=\"link-explore\"><p>Explore</p></div>\n              <div class=\"link\" id=\"link-feed\"><p>Feed</p></div>\n              <div class=\"link\" id=\"link-profile\"><p>Profile</p></div>\n              <div class=\"link\" id=\"link-status\"><p>Status</p></div>\n              <div class=\"link\" id=\"link-landing\"><p>Landing</p></div>\n            </div>\n          </div>\n        </div>\n      </div>\n    "));
  page.css("\n    .link {\n      cursor:pointer;\n      border: ".concat(display.get("global")["border"], ";\n      width: 20%;\n      height: 40%;\n      font-size: ").concat(display.get("text")["size"][1], ";\n      color: ").concat(display.get("text")["color"], ";\n      font-family: '").concat(display.get("text")["font"], "', sans-serif;\n      font-weight: 400;\n      text-align:center;\n      border-radius: ").concat(display.get("global")["border-radius"][0], ";\n      margin:5%;\n      margin-top:0;\n      margin-bottom:0;\n      display: flex;\n      justify-content:center;\n      align-items:center;\n    }\n    #links-container {\n      display: flex;\n      flex-wrap: wrap;\n      width:100%;\n      height:70%;\n      position:absolute;\n      top:25%;\n      left:0;\n      justify-content:center;\n      align-items:center;\n    }\n    #lb-container {\n      display:flex;\n      justify-content:space-evenly;\n      position:absolute;\n      left:0;\n      flex-direction:row;\n      width:100%;\n      height:70%;\n      top:20%;\n      align-items:center;\n    }\n    .lb {\n      font-size: ").concat(display.get("text")["size"][1], ";\n      color: ").concat(display.get("text")["color"], ";\n      font-family: '").concat(display.get("text")["font"], "', sans-serif;\n      font-weight: 400;\n      text-align:center;\n    }\n    .lb-big {\n      font-size: ").concat(display.get("text")["size"][3], ";\n    }\n    #stats {\n      font-size: ").concat(display.get("text")["size"][3], ";\n    }\n    #icon-1 {\n      font-size: ").concat(display.get("text")["size"][3], ";\n    }\n    #icon-2 {\n      font-size: ").concat(display.get("text")["size"][3], ";\n    }\n    #icon-3 {\n      font-size: ").concat(display.get("text")["size"][3], ";\n    }\n    #icon-4 {\n      font-size: ").concat(display.get("text")["size"][3], ";\n    }\n    .stat {\n      font-size: ").concat(display.get("text")["size"][3], ";\n      color: ").concat(display.get("text")["color"], ";\n      font-family: '").concat(display.get("text")["font"], "', sans-serif;\n      font-weight: 400;\n    }\n    #stats-container {\n      display:flex;\n      justify-content:center;\n      position:absolute;\n      top:0;\n      left:0;\n      flex-direction:column;\n      width:100%;\n      height:70%;\n      top:20%;\n      align-items:center;\n    }\n    #welcome {\n      font-family: '").concat(display.get("text")["font"], "', sans-serif;\n      font-weight: 400;\n      color: ").concat(display.get("text")["color"], ";\n      font-size: ").concat(display.get("text")["size"][2], ";\n      margin-left:5px;\n    }\n    #balance {\n      font-family: '").concat(display.get("text")["font"], "', sans-serif;\n      font-weight: 500;\n      color: ").concat(display.get("text")["color"], ";\n      font-size: ").concat(display.get("text")["size"][4], ";\n      display:flex;\n      justify-content:flex-end;\n      align-items:center;\n      margin-left:2.5%;\n      margin-right:22px;\n    }\n    #cont-1-5 {\n      position:absolute;\n      display:flex;\n      justify-content:flex-start;\n      align-items:center;\n      top:5%;\n      left:2.5%;\n      width:50%;\n    }\n    #cont-1-8 {\n      position:absolute;\n      display:flex;\n      justify-content:flex-start;\n      align-items:center;\n      top:0;\n      left:0;\n      width:100%;\n      height:100%;\n    }\n    #balance img {\n      width:75px;\n      height:75px;\n    }\n    .title {\n      font-family: '").concat(display.get("text")["font"], "', sans-serif;\n      font-weight: 400;\n      color: ").concat(display.get("text")["color"], ";\n      font-size: ").concat(display.get("text")["size"][2], ";\n      position:absolute;\n      top:5%;\n      left:2.5%;\n    }\n    #big-container {\n      width:100%;\n      height:100%;\n      display:flex;\n      justify-content:center;\n      align-items:center;\n      position:absolute;\n      top:0;\n      left:0;\n    }\n    #container {\n      width:80%;\n      height:80%;\n    }\n    .container {\n      border: ").concat(display.get("global")["border"], ";\n      border-radius: ").concat(display.get("global")["border-radius"][1], ";\n      position:absolute;\n    }\n    #cont-1{\n      width:80%;\n      height:39%;\n      top:10%;\n      left:10%;\n    }\n\n    #cont-1 img{\n      width:65px;\n      border-radius:256px;\n      height:65px;\n    }\n\n    #cont-2{\n      width:39.75%;\n      height:39%;\n      top:50%;\n      left:10%;\n    }\n    #cont-3{\n      width:39.75%;\n      height:19%;\n      right:10%;\n      top:50%;\n    }\n    #cont-4{\n      width:39.75%;\n      height:19%;\n      right:10%;\n      top:70%;\n    }\n  "));
  function on_render() {
    document.getElementById("welcome").innerText = "Welcome back " + getCookie("v1-user") + ".";
    document.getElementById("dash-profile-picture").src = getCookie("v1-profile-picture");
    document.getElementById("link-settings").onclick = function () {
      router.navigateTo("/settings");
    };
    document.getElementById("link-profile").onclick = function () {
      router.navigateTo("/profile/" + getCookie("v1-id"));
    };
    document.getElementById("link-status").onclick = function () {
      router.navigateTo("/status");
    };
    document.getElementById("link-landing").onclick = function () {
      router.navigateTo("/");
    };
    document.getElementById("link-feed").onclick = function () {
      router.navigateTo("/feed");
    };
    document.getElementById("link-explore").onclick = function () {
      router.navigateTo("/explore");
    };
    Balance(getCookie("v1-id")).then(function (balance) {
      if (balance === false) {
        Notification(1, "An error occured. Code: u404d ");
        router.navigateTo("/explore");
        return "";
      }
      document.getElementById("balance").innerText = "Balance: " + Math.floor(balance);
    });
    Stats(getCookie("v1-id")).then(function (data) {
      if (data === false) {
        Notification(1, "An error occured. Code: u404d ");
        router.navigateTo("/explore");
        return "";
      }
      document.getElementById("likes").innerText = data["likes"];
      document.getElementById("views").innerText = data["views"];
    });
  }
  page.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.on_render(on_render);
  page.render();
}

},{"../elements/background.mjs":2,"../elements/fonts.mjs":4,"../elements/navbar.mjs":6,"../elements/notifications.mjs":8,"../lib/Framework.mjs":10,"../scripts/api.mjs":29,"../scripts/cookies.mjs":30}],14:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.NotFound = NotFound;
function NotFound(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page,
    Display = _require.Display;
  var _require2 = require("../elements/fonts.mjs"),
    Fonts = _require2.Fonts;
  var _require3 = require("../elements/background.mjs"),
    Background = _require3.Background;
  var _require4 = require("../elements/navbar.mjs"),
    Navbar = _require4.Navbar;
  var _require5 = require("../elements/footer.mjs"),
    Footer = _require5.Footer;
  var page = new Page("NotFound");
  var display = new Display();
  page.clear(["background", "navbar", "fonts", "footer"]);
  Fonts(router);
  Background(router);
  Navbar(router);
  Footer(router);
  page.html("<div id=\"center-contain\">\n        <div id=\"error-code\"> 404 </div>\n        <h3> I don\u2019t know who or what went wrong, but someone or something sure went ! </h3>\n        <a class=\"button\" id=\"main-menu\">Main Menu</a>\n    </div>");
  page.css("\n    #center-contain {\n        z-index:0;\n        width: 100%;\n        height: 100%;\n        position:absolute;\n        top:0;\n        left:0;\n        display:flex;\n        justify-content:center;\n        align-items:center;\n        flex-direction: column;\n    }\n\n    #error-code {\n        text-align: center;\n        font-family: ".concat(display.get("text")["font"], ", sans-serif;\n        font-size: ").concat(display.get("text")["size"][4], ";\n        font-style: normal;\n        font-weight: 600;\n        line-height: normal;\n        background: linear-gradient(149deg, ").concat(display.get("background")["elipse-color"][0], " 0%, ").concat(display.get("background")["elipse-color"][1], " 100%);\n        -webkit-background-clip: text;\n        color: transparent;\n    }\n\n    h3 {\n        font-family: ").concat(display.get("text")["font"], ", sans-serif;\n        color: ").concat(display.get("text")["color"], ";\n        text-align: center;\n        font-weight: 400;\n    }\n\n    .button {\n      position:relative;\n      cursor:pointer;\n      color: ").concat(display.get("text")["color"], ";\n      font-family: ").concat(display.get("text")["font"], ", sans-serif;\n      font-size: ").concat(display.get("text")["size"][3], ";\n      font-weight: 400;\n      z-index: 10;\n    }\n\n    #main-menu {\n      position:relative;\n      cursor:pointer;\n      color: ").concat(display.get("text")["color"], ";\n      font-family: ").concat(display.get("text")["font"], ", sans-serif;\n      font-size: ").concat(display.get("text")["size"][3], ";\n      font-weight: 400;\n      z-index: 10;\n    }\n\n    a {\n        cursor: pointer;\n        text-decoration: none;\n    }\n"));
  page.delete_animation("\n    @keyframes delete {\n        0% {\n          opacity: 1;\n          transform: translateY(0%);\n        }\n        100% {\n          opacity: 0;\n          transform: translateY(10%); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  function on_render() {
    document.getElementById("main-menu").onclick = function () {
      router.navigateTo("/");
    };
  }
  page.on_render(on_render);
  page.render();
}

},{"../elements/background.mjs":2,"../elements/fonts.mjs":4,"../elements/footer.mjs":5,"../elements/navbar.mjs":6,"../lib/Framework.mjs":10}],15:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Explore = Explore;
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }
function Explore(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page;
  var _require2 = require("../elements/fonts.mjs"),
    Fonts = _require2.Fonts;
  var _require3 = require("../elements/background.mjs"),
    Background = _require3.Background;
  var _require4 = require("../elements/navbar.mjs"),
    Navbar = _require4.Navbar;
  var _require5 = require("../elements/post.mjs"),
    Post = _require5.Post;
  var _require6 = require("../scripts/api.mjs"),
    IsLogedIn = _require6.IsLogedIn;
  var _require7 = require("../elements/notifications.mjs"),
    Notification = _require7.Notification;
  var _require8 = require("../elements/new_post_button.mjs"),
    NewPostButton = _require8.NewPostButton;
  var page = new Page("Explore");
  page.clear(["background", "navbar", "fonts", "new_post_button"]);
  Fonts(router);
  Background(router);
  Navbar(router);
  NewPostButton(router);
  page.html("\n    <div id=\"post-container\">\n\n    </div>\n    ");
  page.css("\n\n    #post-container {\n        margin-top: 7.5%;\n        position: absolute;\n        min-height:100%;\n        width:100%;\n        height:fit-content;\n        top:0;\n        left:0;\n        display:flex;\n        justify-content:start;\n        align-items:center;\n        flex-direction:column;\n    }\n\n    #post-container post {\n      width:60%;\n      height:fit-content;\n      min-height: 5%;\n      margin: 1%\n    }\n    ");
  var api_url = "wss://api.blockcoin.social";
  if (window.location.hostname == "127.0.0.1" || window.location.hostname == "localhost") {
    api_url = "ws://127.0.0.1:8080";
  }
  var socket = null;
  function on_render() {
    socket = new WebSocket(api_url + '/post');
    var cache = [];
    function waitForNonNullCache() {
      var interval = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 100;
      return new Promise(function (resolve) {
        function checkVariable() {
          cache;
          if (cache !== null) {
            resolve(cache);
          } else {
            setTimeout(checkVariable, interval);
          }
        }
        checkVariable();
      });
    }
    function parsecache() {
      if (cache != null) {
        if (cache["opcode"] == 2) {
          for (var _i = 0, _Object$entries = Object.entries(cache["data"]); _i < _Object$entries.length; _i++) {
            var _Object$entries$_i = _slicedToArray(_Object$entries[_i], 2),
              key = _Object$entries$_i[0],
              value = _Object$entries$_i[1];
            try {
              var post = value;
              var post_data = post["data"];
              post_data["user-id"] = post["profile"]["id"];
              post_data["user"] = post["profile"]["display"];
              post_data["profile-picture"] = post["profile"]["profile-picture"];
              post_data["badges"] = post["profile"]["badges"];
              var new_post = new Post(router, post_data, document.getElementById("post-container"));
            } catch (e) {
              console.log("Error", e.stack);
              console.log("Error", e.name);
              console.log("Error", e.message);
            }
          }
        }
      }
    }
    socket.addEventListener('message', function (event) {
      var data = JSON.parse(event.data);
      cache = data;
      parsecache();
    });
    socket.addEventListener('close', function (event) {
      socket = new WebSocket(api_url + '/post');
    });
    socket.addEventListener('open', function (event) {
      socket.send(JSON.stringify({
        'opcode': 2,
        'limit': 10
      }));
    });
    window.onscroll = function () {
      var scrollHeight = document.documentElement.scrollHeight;
      var scrollTop = window.pageYOffset !== undefined ? window.pageYOffset : (document.documentElement || document.body.parentNode || document.body).scrollTop;
      var windowHeight = window.innerHeight;
      if (scrollTop + windowHeight >= scrollHeight) {
        socket.send(JSON.stringify({
          'opcode': 2,
          'limit': 20
        }));
        parsecache();
      }
    };
  }
  page.delete_animation("\n    @keyframes delete {\n        0% {\n          opacity: 1;\n          transform: translateY(0%);\n        }\n        100% {\n          opacity: 0;\n          transform: translateY(10%); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  function on_delete() {
    socket.close();
  }
  page.on_delete(on_delete);
  page.on_render(on_render);
  page.render();
}

},{"../elements/background.mjs":2,"../elements/fonts.mjs":4,"../elements/navbar.mjs":6,"../elements/new_post_button.mjs":7,"../elements/notifications.mjs":8,"../elements/post.mjs":9,"../lib/Framework.mjs":10,"../scripts/api.mjs":29}],16:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Feed = Feed;
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function Feed(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page,
    Display = _require.Display;
  var _require2 = require("../elements/fonts.mjs"),
    Fonts = _require2.Fonts;
  var _require3 = require("../elements/background.mjs"),
    Background = _require3.Background;
  var _require4 = require("../elements/navbar.mjs"),
    Navbar = _require4.Navbar;
  var _require5 = require("../elements/post.mjs"),
    Post = _require5.Post;
  var _require6 = require("../scripts/api.mjs"),
    IsLogedIn = _require6.IsLogedIn;
  var _require7 = require("../elements/notifications.mjs"),
    Notification = _require7.Notification;
  var _require8 = require("../elements/new_post_button.mjs"),
    NewPostButton = _require8.NewPostButton;
  var _require9 = require("../scripts/cookies.mjs"),
    setCookie = _require9.setCookie,
    getCookie = _require9.getCookie,
    checkCookie = _require9.checkCookie;
  if (IsLogedIn() == false) {
    Notification(1, "You need to be logged in to have a feed.");
    router.navigateTo("/explore");
    return "";
  }
  var display = new Display();
  var page = new Page("Feed");
  page.clear(["background", "navbar", "fonts", "new_post_button"]);
  Fonts(router);
  Background(router);
  Navbar(router);
  NewPostButton(router);
  page.html("\n    <div id=\"post-container\">\n      <div id=\"empty\"><italic>It's pretty empty in there, you should follow <strong><span id=\"me\">me</span></strong> to have some activity :)</italic></div>\n    </div>\n    ");
  page.css("\n    #me {\n      cursor:pointer;\n      text-decoration: underline;\n    }\n    #empty {\n      font-family: ".concat(display.get("text")["font"], ", sans-serif;\n      font-weight: 300;\n      font-size: ").concat(display.get("text")["size"][0], ";\n      color: ").concat(display.get("text")["color"], ";\n    }\n    #post-container {\n        margin-top: 7.5%;\n        position: absolute;\n        min-height:100%;\n        width:100%;\n        height:fit-content;\n        top:0;\n        left:0;\n        display:flex;\n        justify-content:start;\n        align-items:center;\n        flex-direction:column;\n    }\n\n    #post-container post {\n      width:60%;\n      height:fit-content;\n      min-height: 5%;\n      margin: 1%\n    }\n"));
  var api_url = "wss://api.blockcoin.social";
  if (window.location.hostname == "127.0.0.1" || window.location.hostname == "localhost") {
    api_url = "ws://127.0.0.1:8080";
  }
  var socket = null;
  function on_render() {
    socket = new WebSocket(api_url + '/post');
    var cache = null;
    var offset = 0;
    var opcode = 7;
    function waitForNonNullCache() {
      var interval = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 100;
      return new Promise(function (resolve) {
        function checkVariable() {
          cache;
          if (cache !== null) {
            resolve(cache);
          } else {
            setTimeout(checkVariable, interval);
          }
        }
        checkVariable();
      });
    }
    function parsecache() {
      if (cache != null) {
        if (cache["opcode"] == opcode) {
          var dataArray = cache["data"];
          var _iterator = _createForOfIteratorHelper(dataArray.entries()),
            _step;
          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var _step$value = _slicedToArray(_step.value, 2),
                index = _step$value[0],
                value = _step$value[1];
              var element = document.getElementById('empty');
              if (element !== null) {
                element.remove();
              }
              try {
                var post = value;
                var post_data = post["data"];
                post_data["user-id"] = post["profile"]["id"];
                post_data["user"] = post["profile"]["display"];
                post_data["profile-picture"] = post["profile"]["profile-picture"];
                post_data["badges"] = post["profile"]["badges"];
                var new_post = new Post(router, post_data, document.getElementById("post-container"));
              } catch (e) {
                console.log("Error", e.stack);
                console.log("Error", e.name);
                console.log("Error", e.message);
              }
            }
          } catch (err) {
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
        }
      }
    }
    socket.addEventListener('message', function (event) {
      var data = JSON.parse(event.data);
      cache = data;
      parsecache();
    });
    socket.addEventListener('close', function (event) {
      socket = new WebSocket(api_url + '/post');
    });
    socket.addEventListener('open', function (event) {
      socket.send(JSON.stringify({
        'opcode': opcode,
        'offset': offset,
        "user": getCookie("v1-id"),
        "token": getCookie("v1-token")
      }));
      offset++;
    });
    window.onscroll = function () {
      var scrollHeight = document.documentElement.scrollHeight;
      var scrollTop = window.pageYOffset !== undefined ? window.pageYOffset : (document.documentElement || document.body.parentNode || document.body).scrollTop;
      var windowHeight = window.innerHeight;
      if (scrollTop + windowHeight >= scrollHeight) {
        socket.send(JSON.stringify({
          'opcode': opcode,
          'offset': offset,
          "user": getCookie("v1-id"),
          "token": getCookie("v1-token")
        }));
        offset++;
        parsecache();
      }
    };
    document.getElementById("me").onclick = function () {
      router.navigateTo("/profile/3eop5-002lb-v2904-fcpfs-bs9xf");
    };
  }
  page.delete_animation("\n    @keyframes delete {\n        0% {\n          opacity: 1;\n          transform: translateY(0%);\n        }\n        100% {\n          opacity: 0;\n          transform: translateY(10%); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  function on_delete() {
    socket.close();
  }
  page.on_delete(on_delete);
  page.on_render(on_render);
  page.render();
}

},{"../elements/background.mjs":2,"../elements/fonts.mjs":4,"../elements/navbar.mjs":6,"../elements/new_post_button.mjs":7,"../elements/notifications.mjs":8,"../elements/post.mjs":9,"../lib/Framework.mjs":10,"../scripts/api.mjs":29,"../scripts/cookies.mjs":30}],17:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Landing = Landing;
function Landing(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page,
    Display = _require.Display;
  var _require2 = require("../elements/fonts.mjs"),
    Fonts = _require2.Fonts;
  var _require3 = require("../elements/background.mjs"),
    Background = _require3.Background;
  var _require4 = require("../elements/navbar.mjs"),
    Navbar = _require4.Navbar;
  var _require5 = require("../elements/footer.mjs"),
    Footer = _require5.Footer;
  var _require6 = require("../elements/new_post_button.mjs"),
    NewPostButton = _require6.NewPostButton;
  var page = new Page("Landing");
  var display = new Display();
  page.clear(["background", "navbar", "fonts", "footer", "new_post_button"]);
  NewPostButton(router);
  Fonts(router);
  Background(router);
  Navbar(router);
  Footer(router);
  var border = page.image("border.svg");
  var mockup = page.image("Mockup.png");
  var mockupfront = page.image("MockupFront.png");
  page.html("\n        <div class=\"container\" id=\"container\">\n            <div class=\"text big\">Write, Post, Earn.</div>\n            <div class=\"text small\">Join us on a new social adventure today!</div>\n            <div id=\"button\">Sign-Up Now</div>\n        </div>\n        <div class=\"container-2\" id=\"container-2\">\n            <img id=\"mockup\" src=\"".concat(mockup, "\" alt=\"Blockcoin mobile app mockup.\"></img>\n        </div> \n    "));
  page.css("\n    .text {\n        font-family: '".concat(display.get("text")["font"], "', sans-serif;\n        font-weight: ").concat(display.get("text")["font-weight-bold"], ";\n        font-size: ").concat(display.get("text")["size"][4], ";\n        color: ").concat(display.get("text")["color"], ";\n      }\n      \n      \n      .small {\n        font-weight: ").concat(display.get("text")["font-weight-light"], ";\n        font-size: ").concat(display.get("text")["size"][1], ";\n      }\n      \n      .container {\n        z-index:50;\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        flex-direction: column;\n        top:0;\n        left:0;\n        height: 100%;\n        width: 50%;\n        position: absolute;\n        gap: 10px;\n      }\n      ::-webkit-scrollbar {\n        width: 10px;\n      }\n      \n      ::-webkit-scrollbar-track {\n        background: none;\n      }\n      \n      ::-webkit-scrollbar-thumb {\n        background: ").concat(display.get("background")["elipse-color"][0], ";\n        border-radius: 360px;\n      }\n      \n      ::-webkit-scrollbar-thumb:hover {\n        background: ").concat(display.get("background")["elipse-color"][1], ";\n      }\n      \n      .container-2 {\n        overflow: hidden;\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        flex-direction: column;\n        top:0;\n        right:0;\n        height: 100%;\n        width: 50%;\n        position: absolute;\n        z-index: 4;\n      }\n      \n      #button {\n        border-radius: ").concat(display.get("global")["border-radius"][1], ";\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        font-family: '").concat(display.get("text")["font"], "', sans-serif;\n        font-weight: ").concat(display.get("text")["font-weight-light"], ";\n        color:").concat(display.get("text")["color"], ";\n        font-size: ").concat(display.get("text")["size"][2], ";\n        background: url(").concat(border, ");\n        box-shadow: none;\n        cursor: pointer;\n        width: 360px;\n        height: 70px;\n        z-index:100;\n      }\n\n    @media screen and (max-width: 1270px){\n            #mockup {\n              content: url(").concat(mockupfront, ");\n            }\n            #container {\n                width: 100%; \n                height: 100%;\n              }\n            #container-2 {\n                top: 50%;\n                width:100%;\n            }\n            footer {\n              position:absolute;\n              top:150%;\n            }\n            #copy {\n              top:100%\n            }\n            #blur {\n              height: 150%;\n            }\n            .elipse {\n              height: 48vw;\n              width: 48vw;\n            }\n          }\n          \n          @media screen and (max-width: 650px){\n          \n            .big {\n              font-size: 10.7vw;\n            }\n            .small {\n              font-size: 4.6vw;\n            }\n            \n          }\n          \n          @media screen and (max-width: 550px){\n            \n            #navbar {\n              display: flex;\n              justify-content: center;\n              align-items: center;\n              position: absolute;\n              flex-direction: column;\n              margin-top: 20px;\n            }\n            .container-3 {\n              display: flex;\n              justify-content: space-around;\n              align-items: center;\n              width: 100%;\n            }\n            .trans-button {\n              width: 30%;\n              text-align: center;\n            }\n          \n            #copy {\n              margin: 0;\n              top:0;\n              width:100%;\n              left:0;\n              text-align: center;\n            }\n            .container-links {\n              width: 100%;\n              margin-bottom: 0px;\n            }\n            .container-titles {\n              width: 100%;\n              margin-bottom: 0px;\n            }\n            footer {\n              overflow: hidden;\n              height: 20%;\n            }\n            .container-4{\n              position: absolute;\n              bottom: 30%;\n            }\n          }\n      }\n    "));
  page.delete_animation("\n    @keyframes delete {\n        0% {\n          opacity: 1;\n          transform: translateY(0%);\n        }\n        100% {\n          opacity: 0;\n          transform: translateY(10%); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  function on_render() {
    document.getElementById("button").onclick = function () {
      router.navigateTo("/register");
    };
  }
  page.on_render(on_render);
  page.render();
}

},{"../elements/background.mjs":2,"../elements/fonts.mjs":4,"../elements/footer.mjs":5,"../elements/navbar.mjs":6,"../elements/new_post_button.mjs":7,"../lib/Framework.mjs":10}],18:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Live = Live;
var _cookies = require("../scripts/cookies.mjs");
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }
function Live(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page,
    Display = _require.Display;
  var _require2 = require("../elements/fonts.mjs"),
    Fonts = _require2.Fonts;
  var _require3 = require("../elements/background.mjs"),
    Background = _require3.Background;
  var _require4 = require("../elements/navbar.mjs"),
    Navbar = _require4.Navbar;
  var _require5 = require("../elements/post.mjs"),
    Post = _require5.Post,
    LivePost = _require5.LivePost;
  var _require6 = require("../scripts/api.mjs"),
    IsLogedIn = _require6.IsLogedIn;
  var _require7 = require("../elements/notifications.mjs"),
    Notification = _require7.Notification;
  var _require8 = require("../elements/new_post_button.mjs"),
    NewPostButton = _require8.NewPostButton;
  var page = new Page("Live");
  var display = new Display();
  page.clear(["background", "navbar", "fonts"]);
  Fonts(router);
  Background(router);
  Navbar(router);
  page.html("\n    <div id=\"post-container\">\n\n    </div>\n    <input class=\"text-input\"  id=\"message\"></input>\n    ");
  page.css("\n    #post-container {\n        margin-top: 7.5%;\n        position: absolute;\n        min-height:100%;\n        width:100%;\n        height:fit-content;\n        top:0;\n        left:0;\n        display:flex;\n        justify-content:start;\n        align-items:center;\n        flex-direction:column;\n    }\n    .text-input {\n      backdrop-filter: blur(".concat(display.get("background")["blur"], ");\n      width:90%;\n      outline:none;\n      background:none;\n      border:solid 1px ").concat(display.get("text")["color"], ";\n      border-radius:").concat(display.get("global")["border-radius"][1], ";\n      min-height:50px;\n      font-family: '").concat(display.get("text")["font"], "', sans-serif;\n      font-weight: ").concat(display.get("text")["font-weight"], ";\n      color:").concat(display.get("text")["color"], ";\n      font-size: ").concat(display.get("text")["size"][3], ";\n      text-align:left;\n      margin-bottom:15px;\n      position:fixed;\n      left:5%;\n      bottom:0;\n    }\n\n    #post-container post {\n      width:60%;\n      height:fit-content;\n      min-height: 5%;\n      margin: 1%\n    }\n"));
  var api_url = "wss://api.blockcoin.social";
  if (window.location.hostname == "127.0.0.1" || window.location.hostname == "localhost") {
    api_url = "ws://127.0.0.1:8080";
  }
  var socket = null;
  function on_render() {
    socket = new WebSocket(api_url + '/post');
    var cache = [];
    document.getElementById("message").addEventListener('keypress', function (e) {
      if (e.key === 'Enter') {
        socket.send(JSON.stringify({
          'opcode': 6,
          'type': 3,
          'user': (0, _cookies.getCookie)("v1-id"),
          'token': (0, _cookies.getCookie)("v1-token"),
          'message': document.getElementById("message").value
        }));
      }
    });
    function waitForNonNullCache() {
      var interval = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 100;
      return new Promise(function (resolve) {
        function checkVariable() {
          cache;
          if (cache !== null) {
            resolve(cache);
          } else {
            setTimeout(checkVariable, interval);
          }
        }
        checkVariable();
      });
    }
    function parsecache() {
      if (cache != null) {
        if (cache["opcode"] == 6 && cache["type"] == 2) {
          for (var _i = 0, _Object$entries = Object.entries(cache["data"]); _i < _Object$entries.length; _i++) {
            var _Object$entries$_i = _slicedToArray(_Object$entries[_i], 2),
              key = _Object$entries$_i[0],
              value = _Object$entries$_i[1];
            try {
              var post = value;
              var post_data = post["data"];
              post_data["user-id"] = post["profile"]["id"];
              post_data["user"] = post["profile"]["display"];
              post_data["profile-picture"] = post["profile"]["profile-picture"];
              post_data["badges"] = post["profile"]["badges"];
              var new_post = new LivePost(router, post_data, document.getElementById("post-container"));
            } catch (e) {
              console.log("Error", e.stack);
              console.log("Error", e.name);
              console.log("Error", e.message);
            }
          }
        }
      }
    }
    socket.addEventListener('message', function (event) {
      var data = JSON.parse(event.data);
      cache = data;
      parsecache();
    });
    socket.addEventListener('close', function (event) {
      socket = new WebSocket(api_url + '/post');
    });
    socket.addEventListener('open', function (event) {
      socket.send(JSON.stringify({
        'opcode': 6,
        'type': 1,
        'user': (0, _cookies.getCookie)("v1-id"),
        'token': (0, _cookies.getCookie)("v1-token")
      }));
      waitForNonNullCache().then(function (value) {
        parsecache();
      });
    });
  }
  ;
  page.delete_animation("\n    @keyframes delete {\n        0% {\n          opacity: 1;\n          transform: translateY(0%);\n        }\n        100% {\n          opacity: 0;\n          transform: translateY(10%); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  function on_delete() {
    socket.send(JSON.stringify({
      'opcode': 6,
      'type': 4,
      'user': (0, _cookies.getCookie)("v1-id"),
      'token': (0, _cookies.getCookie)("v1-token")
    }));
    socket.close();
  }
  page.on_delete(on_delete);
  page.on_render(on_render);
  page.render();
}

},{"../elements/background.mjs":2,"../elements/fonts.mjs":4,"../elements/navbar.mjs":6,"../elements/new_post_button.mjs":7,"../elements/notifications.mjs":8,"../elements/post.mjs":9,"../lib/Framework.mjs":10,"../scripts/api.mjs":29,"../scripts/cookies.mjs":30}],19:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Login = Login;
function Login(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page,
    Display = _require.Display;
  var _require2 = require("../elements/fonts.mjs"),
    Fonts = _require2.Fonts;
  var _require3 = require("../elements/background.mjs"),
    Background = _require3.Background;
  var _require4 = require("../elements/navbar.mjs"),
    Navbar = _require4.Navbar;
  var _require5 = require("../elements/footer.mjs"),
    Footer = _require5.Footer;
  var _require6 = require("../scripts/api.mjs"),
    Login = _require6.Login;
  var _require7 = require("../elements/notifications.mjs"),
    Notification = _require7.Notification;
  var page = new Page("Login");
  var display = new Display();
  var blank_logo = page.image("logo_blank.svg");
  var login_button = page.image("login_button.svg");
  page.clear(["background", "navbar", "fonts", "footer"]);
  Fonts(router);
  Background(router);
  Navbar(router);
  Footer(router);
  page.html("\n    <script src=\"https://www.google.com/recaptcha/api.js?render=6Lf1n4IoAAAAAEXFEel1BfkxHrcuzJUJNfPiFA3q\"></script>\n    <div class=\"container\">\n        <img src=\"".concat(blank_logo, "\" alt=\"A white version of the blockcoin logo.\"></img>\n        <div class=\"text\">Write, Post, Earn.</div>\n    </div>\n    <div class=\"container-2\">\n        <div class=\"text small\">Login</div>\n        <div class=\"form\">\n            <span class=\"material-symbols-outlined\">account_circle</span>\n            <input placeholder=\"Username\" id=\"username\" type=\"text\"></input>\n        </div>\n        <div class=\"form\">\n            <span class=\"material-symbols-outlined\">password</span>\n            <input placeholder=\"Password\" id=\"password\" type=\"password\"></input>\n        </div>\n        <img src=\"").concat(login_button, "\" alt=\"The login button\" id=\"Login\"></img>\n        <button id=\"Register\">Or Register</button>\n        \n        <div class=\"text very-small\">This site is protected by reCAPTCHA. <br>The Google\n        <a href=\"https://policies.google.com/privacy\" class=\"g-link\">Privacy Policy</a> and\n        <a href=\"https://policies.google.com/terms\" class=\"g-link\">Terms of Service</a> apply.</div>\n    </div>\n    "));
  page.css("\n    .g-link {\n      color: ".concat(display.get("text")["color"], ";\n    } \n\n    .text {\n        font-family: '").concat(display.get("text")["font"], "', sans-serif;\n        font-weight: ").concat(display.get("text")["font-weight-bold"], ";\n        font-size: ").concat(display.get("text")["size"][4], ";\n        color: ").concat(display.get("text")["color"], ";\n      }\n      \n      \n      .small {\n        font-weight: ").concat(display.get("text")["font-weight-light"], ";\n        font-size: ").concat(display.get("text")["size"][1], ";\n      }\n      \n      .very-small {\n        margin:1%;\n        text-align: center;\n        font-size: 15px;\n        font-weight: ").concat(display.get("text")["font-weight-light"], ";\n        color: ").concat(display.get("text")["color"], ";\n      }\n      \n      .container {\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        flex-direction: column;\n        top:0;\n        left:0;\n        height: 100%;\n        width: 50%;\n        position: absolute;\n        z-index: 4;\n        gap: 10px;\n      }\n      ::-webkit-scrollbar {\n        width: 10px;\n      }\n      \n      ::-webkit-scrollbar-track {\n        background: none;\n      }\n      \n      ::-webkit-scrollbar-thumb {\n        background: ").concat(display.get("background")["elipse-color"][0], ";\n        border-radius: 360px;\n      }\n      \n      ::-webkit-scrollbar-thumb:hover {\n        background: ").concat(display.get("background")["elipse-color"][1], ";\n      }\n      \n      .container-2 {\n        overflow: hidden;\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        flex-direction: column;\n        top:0;\n        right:0;\n        height: 100%;\n        width: 50%;\n        position: absolute;\n        z-index: 4;\n      }\n      \n      #button {\n        border-radius: ").concat(display.get("global")["border-radius"][1], ";\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        font-family: '").concat(display.get("text")["font"], "', sans-serif;\n        font-weight: ").concat(display.get("text")["font-weight-light"], ";\n        color:").concat(display.get("text")["color"], ";\n        font-size: ").concat(display.get("text")["size"][3], ";\n        background: url(border.svg);\n        border: none;\n        box-shadow: none;\n        cursor: pointer;\n        width: 360px;\n        height: 70px;\n      }\n      .form {\n        width: 375px;\n        height: 55px;\n        border-bottom: 1px solid ").concat(display.get("text")["color"], ";\n        display: flex;\n        justify-content: space-between;\n        align-items: center;\n      }\n      \n      .form span{\n        color: ").concat(display.get("text")["color"], ";\n        font-size: ").concat(display.get("text")["size"][3], ";\n      }\n      \n      .form input{\n        background: none;\n        text-align: right;\n        color: ").concat(display.get("text")["color"], ";\n        height: 100%;\n        border: none;\n        font-size: ").concat(display.get("text")["size"][0], ";\n        width: 80%;\n      }\n      \n      .form input:focus {\n        outline:none!important;\n      }\n      \n      ::placeholder {\n        color: ").concat(display.get("text")["color"], ";\n      }\n      \n      p{color:").concat(display.get("text")["color"], "}\n      \n      #Login {\n        cursor: pointer;\n        margin-top: 30px;\n        border: none;\n        width: 330px;\n        height: 53px;\n      }\n      \n      #Register {\n        cursor: pointer;\n        background: none;\n        border: none;\n        font-family: '").concat(display.get("text")["font"], "', sans-serif;\n        font-weight: ").concat(display.get("text")["font-weight-light"], ";\n        color:").concat(display.get("text")["color"], ";\n        font-size: ").concat(display.get("text")["size"][1], ";\n        margin-top: 5px;\n      }\n      @media screen and (max-width: 1270px){\n        #mockup {\n          content: url(MockupFront.png);\n        }\n        .container {\n          display: none;\n          width: 100%; \n          height: 100%;\n        }\n        .container-2 {\n          width:100%;\n        }\n        footer {\n          position:absolute;\n          top:150%;\n        }\n        #copy {\n          top:100%\n        }\n        .elipse {\n          height: 48vw;\n          width: 48vw;\n        }\n      }\n      \n      @media screen and (max-width: 650px){\n      \n        .big {\n          font-size: 10.7vw;\n        }\n        .small {\n          font-size: 4.6vw;\n        }\n      \n      }\n      \n      @media screen and (max-width: 550px){\n      \n        #navbar {\n          display: flex;\n          justify-content: center;\n          align-items: center;\n          position: absolute;\n          flex-direction: column;\n          margin-top: 20px;\n        }\n        .container-3 {\n          display: flex;\n          justify-content: space-around;\n          align-items: center;\n          width: 100%;\n        }\n        .trans-button {\n          width: 30%;\n          text-align: center;\n        }\n      \n        #copy {\n          margin: 0;\n          top:0;\n          width:100%;\n          left:0;\n          text-align: center;\n        }\n        .container-links {\n          width: 100%;\n          margin-bottom: 0px;\n        }\n        .container-titles {\n          width: 100%;\n          margin-bottom: 0px;\n        }\n        footer {\n          overflow: hidden;\n          height: 20%;\n        }\n        .container-4{\n          position: absolute;\n          bottom: 30%;\n        }\n      }\n    "));
  page.delete_animation("\n    @keyframes delete {\n        0% {\n          opacity: 1;\n          transform: translateY(0%);\n        }\n        100% {\n          opacity: 0;\n          transform: translateY(10%); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  function on_render() {
    document.getElementById("Register").onclick = function () {
      router.navigateTo("/register");
    };
    document.getElementById("Login").onclick = function () {
      grecaptcha.ready(function () {
        grecaptcha.execute('6Lf1n4IoAAAAAEXFEel1BfkxHrcuzJUJNfPiFA3q', {
          action: 'submit'
        }).then(function (token) {
          Login(document.getElementById('username').value, document.getElementById('password').value, token).then(function (success) {
            if (success == true) {
              router.navigateTo("/explore");
            } else {
              Notification(1, success);
            }
          })["catch"](function (error) {
            console.error("Error during login:", error);
          });
        });
      });
    };
  }
  page.on_render(on_render);
  page.render();
}

},{"../elements/background.mjs":2,"../elements/fonts.mjs":4,"../elements/footer.mjs":5,"../elements/navbar.mjs":6,"../elements/notifications.mjs":8,"../lib/Framework.mjs":10,"../scripts/api.mjs":29}],20:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Maintenance = Maintenance;
function Maintenance(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page,
    Display = _require.Display;
  var _require2 = require("../elements/fonts.mjs"),
    Fonts = _require2.Fonts;
  var _require3 = require("../elements/background.mjs"),
    Background = _require3.Background;
  var _require4 = require("../elements/navbar.mjs"),
    Navbar = _require4.Navbar;
  var _require5 = require("../elements/footer.mjs"),
    Footer = _require5.Footer;
  var page = new Page("Maintenance");
  var display = new Display();
  page.clear(["background", "fonts"]);
  Fonts(router);
  Background(router);
  page.html("<div id=\"center-contain\">\n        <div id=\"error-code\"> \uD83E\uDD2B </div>\n        <h3>BlockCoin is currently under maintenance, we are sorry for the inconvenience.</h3>\n        <a class=\"button\" id=\"main-menu\">Check the discord for news.</a>\n    </div>");
  page.css("\n    #center-contain {\n        z-index: ".concat(display.get("global")["z-index"][0], ";\n        width: 100%;\n        height: 100%;\n        position:absolute;\n        top:0;\n        left:0;\n        display:flex;\n        justify-content:center;\n        align-items:center;\n        flex-direction: column;\n    }\n\n    #error-code {\n        text-align: center;\n        font-family: ").concat(display.get("text")["font"], ", sans-serif;\n        font-size: ").concat(display.get("text")["size"][5], ";\n        font-style: normal;\n        font-weight: ").concat(display.get("text")["font-weight-bold"], ";\n        line-height: normal;\n        background: linear-gradient(149deg, ").concat(display.get("background")["elipse-color"][0], " 0%, ").concat(display.get("background")["elipse-color"][1], " 100%);\n        -webkit-background-clip: text;\n        color: transparent;\n    }\n\n    h3 {\n        font-family: ").concat(display.get("text")["font"], ", sans-serif;\n        color: ").concat(display.get("text")["color"], ";\n        text-align: center;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n    }\n\n    .button {\n      position:relative;\n      cursor:pointer;\n      color: ").concat(display.get("text")["color"], ";\n      font-family: ").concat(display.get("text")["font"], ", sans-serif;\n      font-size: ").concat(display.get("text")["size"][3], ";\n      font-weight: ").concat(display.get("text")["font-weight"], ";\n      z-index: ").concat(display.get("global")["z-index"][1], ";\n      text-decoration: ").concat(display.get("text")["button-decoration"], ";\n    }\n\n    #main-menu {\n      position:relative;\n      cursor:pointer;\n      color: ").concat(display.get("text")["color"], ";\n      font-family: ").concat(display.get("text")["font"], ", sans-serif;\n      font-size: ").concat(display.get("text")["size"][3], ";\n      font-weight: ").concat(display.get("text")["font-weight"], ";\n      z-index: ").concat(display.get("global")["z-index"][1], ";\n    }\n\n    a {\n        cursor: ").concat(display.get("text")["link-cursor"], ";\n        text-decoration: ").concat(display.get("text")["link-decoration"], ";\n    }\n"));
  page.delete_animation("\n    @keyframes delete {\n        0% {\n          opacity: 1;\n          transform: translateY(0%);\n        }\n        100% {\n          opacity: 0;\n          transform: translateY(10%); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  function on_render() {
    document.getElementById("main-menu").onclick = function () {
      router.navigateTo("/discord");
    };
  }
  page.on_render(on_render);
  page.render();
}

},{"../elements/background.mjs":2,"../elements/fonts.mjs":4,"../elements/footer.mjs":5,"../elements/navbar.mjs":6,"../lib/Framework.mjs":10}],21:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.NewComment = NewComment;
function NewComment(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page,
    Display = _require.Display;
  var _require2 = require("../elements/fonts.mjs"),
    Fonts = _require2.Fonts;
  var _require3 = require("../elements/background.mjs"),
    Background = _require3.Background;
  var _require4 = require("../elements/navbar.mjs"),
    Navbar = _require4.Navbar;
  var _require5 = require("../scripts/api.mjs"),
    IsLogedIn = _require5.IsLogedIn,
    CreateComment = _require5.CreateComment;
  var _require6 = require("../elements/notifications.mjs"),
    Notification = _require6.Notification;
  if (IsLogedIn() == false) {
    Notification(1, "You need to be logged in to create a comment.");
    router.navigateTo("/explore");
    return "";
  }
  var display = new Display();
  var page = new Page("NewComment");
  page.clear(["background", "navbar", "fonts"]);
  Fonts(router);
  Background(router);
  Navbar(router);
  var post_button = page.image("new_comment.svg");
  page.html("\n      <div id=\"container\">\n        <div id=\"new-container\">\n          <div id=\"new-input\" >\n            <div id=\"char-count\">0/250</div>\n            <p contenteditable=\"true\" maxlength=249 placeholder=\"Enter text here...\" id=\"new-input-para\"></p>\n          </div>\n          <div id=\"button-container\">\n            <img id=\"post-button\" src=\"".concat(post_button, "\" />\n          </div>\n        </div>\n      </div>\n    "));
  page.css("\n    #post-button {\n        cursor: pointer;\n    }\n    .option-bg {\n        border-radius: ".concat(display.get("global")["border-radius"][0], ";\n        border: ").concat(display.get("global")["border"], ";\n        height: 30%;\n        width: 80%;\n        display: flex;\n        justify-content: space-between;\n        align-items: center;\n        margin-bottom: 1%;\n        background: ").concat(display.get("global")["background"], ";\n    }\n    .option-input {\n        border-bottom: 2px solid ").concat(display.get("text")["color"], ";\n        border-top: none;\n        border-right: none;\n        border-left: none;\n        margin: 5%;\n        position: relative;\n        display: inline-block;\n        width: 60px;\n        height: 34px;\n        background: none;\n        color: ").concat(display.get("text")["color"], ";\n        text-align: left;\n        font-family: ").concat(display.get("text")["font"], ", sans-serif;\n        font-size: ").concat(display.get("text")["size"][1], ";\n        font-style: normal;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        line-height: normal;\n    }\n    .option-title {\n        margin: 5%;\n        color: ").concat(display.get("text")["color"], ";\n        font-family: ").concat(display.get("text")["font"], ", sans-serif;\n        font-size: ").concat(display.get("text")["size"][2], ";\n        font-style: normal;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        line-height: normal;\n    }\n    #char-count {\n        color: ").concat(display.get("text")["color"], ";\n        font-family: ").concat(display.get("text")["font"], ", sans-serif;\n        font-size: ").concat(display.get("text")["size"][0], ";\n        font-style: normal;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        line-height: normal;\n        width: 100%;\n        text-align: center;\n    }\n    #option-container {\n        height: 30%;\n        width: 100%;\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        flex-direction: column;\n        background: ").concat(display.get("global")["background"], ";\n    }\n    #container {\n        width: 100%;\n        height: 100%;\n        top: 0;\n        left: 0;\n        position: fixed;\n        display: flex;\n        justify-content: center;\n        align-items: center;\n    }\n\n    .switch {\n        margin: 5%;\n        position: relative;\n        display: inline-block;\n        width: 60px;\n        height: 34px;\n    }\n    \n    .switch input {\n        opacity: 0;\n        width: 0;\n        height: 0;\n    }\n    \n    .slider {\n        position: absolute;\n        cursor: pointer;\n        top: 0;\n        left: 0;\n        right: 0;\n        bottom: 0;\n        background-color: ").concat(display.get("global")["background"], ";\n        -webkit-transition: .4s;\n        transition: .4s;\n    }\n    \n    .slider:before {\n        position: absolute;\n        content: \"\";\n        height: 26px;\n        width: 26px;\n        left: 4px;\n        bottom: 4px;\n        background-color: ").concat(display.get("text")["color"], ";\n        -webkit-transition: .4s;\n        transition: .4s;\n    }\n    \n    input:checked + .slider {\n        background-color: #2196F3;\n    }\n    \n    input:focus + .slider {\n        box-shadow: 0 0 1px #2196F3;\n    }\n    \n    input:checked + .slider:before {\n        -webkit-transform: translateX(26px);\n        -ms-transform: translateX(26px);\n        transform: translateX(26px);\n    }\n    \n    .slider.round {\n        border-radius: ").concat(display.get("global")["border-radius"][2], ";\n    }\n    \n    .slider.round:before {\n        border-radius: ").concat(display.get("global")["border-radius"][2], ";\n    }\n\n    #new-container {\n        width: 60%;\n        height: 70%;\n        border-radius: ").concat(display.get("global")["border-radius"][0], ";\n        border: ").concat(display.get("global")["border"], ";\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        flex-direction: column;\n        background: ").concat(display.get("global")["background"], ";\n    }\n\n    #new-input {\n        width: 80%;\n        height: 30%;\n        border-radius: ").concat(display.get("global")["border-radius"][1], ";\n        border: ").concat(display.get("global")["border"], ";\n        background: none;\n        display: flex;\n        align-items: center;\n        justify-content: start;\n        flex-direction: column;\n        margin: 4%;\n        overflow: auto;\n    }\n\n    [contenteditable=true]:empty:before {\n        content: attr(placeholder);\n        pointer-events: none;\n        display: block; /* For Firefox */\n    }\n\n    #new-input-para {\n        width: 100%;\n        outline: none;\n        vertical-align: top;\n        text-align: center;\n        color: ").concat(display.get("text")["color"], ";\n        font-family: ").concat(display.get("text")["font"], ", sans-serif;\n        font-size: ").concat(display.get("text")["size"][2], ";\n        font-style: normal;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        line-height: normal;\n    }\n\n    ::placeholder {\n        color: ").concat(display.get("text")["color"], ";\n    }\n\n    #button-container {\n        margin: 4%;\n        width: 80%;\n        display: flex;\n        justify-content: flex-end;\n        align-items: center;\n    }\n"));
  function on_render() {
    var editableDiv = document.getElementById('new-input-para');
    var maxLength = parseInt(editableDiv.getAttribute('maxlength'));
    var post_id = window.location.pathname.split("/")[2];
    var parent = window.location.pathname.split("/")[3];
    if (parent == undefined) {
      parent = "/";
    }
    document.getElementById("post-button").onclick = function () {
      grecaptcha.ready(function () {
        grecaptcha.execute('6Lf1n4IoAAAAAEXFEel1BfkxHrcuzJUJNfPiFA3q', {
          action: 'submit'
        }).then(function (token) {
          CreateComment(editableDiv.innerText, post_id, parent, token).then(function (success) {
            if (success) {
              router.navigateTo("/post/" + post_id);
            } else {
              console.log("Create Post failed.");
            }
          });
        });
      });
    };
    editableDiv.addEventListener('input', function (event) {
      var text = this.innerText;
      var cursorPosition = getCaretPosition(this);
      document.getElementById("char-count").innerText = text.length + "/250";
      if (text.length > maxLength) {
        event.preventDefault();
        var truncatedText = text.substring(0, maxLength);
        this.innerText = truncatedText;
        setCaretPosition(this, Math.min(cursorPosition, maxLength));
      }
    });
    function getCaretPosition(element) {
      var sel = window.getSelection();
      return sel.anchorOffset;
    }
    function setCaretPosition(element, position) {
      var range = document.createRange();
      var sel = window.getSelection();
      range.setStart(element.childNodes[0], position);
      range.collapse(true);
      sel.removeAllRanges();
      sel.addRange(range);
    }
  }
  ;
  page.delete_animation("\n    @keyframes delete {\n        0% {\n          opacity: 1;\n          transform: translateY(0%);\n        }\n        100% {\n          opacity: 0;\n          transform: translateY(10%); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.on_render(on_render);
  page.render();
}

},{"../elements/background.mjs":2,"../elements/fonts.mjs":4,"../elements/navbar.mjs":6,"../elements/notifications.mjs":8,"../lib/Framework.mjs":10,"../scripts/api.mjs":29}],22:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.NewPost = NewPost;
function NewPost(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page,
    Display = _require.Display;
  var _require2 = require("../elements/fonts.mjs"),
    Fonts = _require2.Fonts;
  var _require3 = require("../elements/background.mjs"),
    Background = _require3.Background;
  var _require4 = require("../elements/navbar.mjs"),
    Navbar = _require4.Navbar;
  var _require5 = require("../scripts/api.mjs"),
    IsLogedIn = _require5.IsLogedIn,
    CreatePost = _require5.CreatePost;
  var _require6 = require("../elements/notifications.mjs"),
    Notification = _require6.Notification;
  if (IsLogedIn() == false) {
    Notification(1, "You need to be logged in to create a post.");
    router.navigateTo("/explore");
    return "";
  }
  var display = new Display();
  var page = new Page("NewPost");
  page.clear(["background", "navbar", "fonts"]);
  Fonts(router);
  Background(router);
  Navbar(router);
  var post_button = page.image("post_button.svg");
  page.html("\n      <div id=\"container\">\n        <div id=\"new-container\">\n          <div id=\"new-input\" >\n            <div id=\"char-count\">0/250</div>\n            <p contenteditable=\"true\" maxlength=249 placeholder=\"Enter text here...\" id=\"new-input-para\"></p>\n          </div>\n          <div id=\"option-container\">\n            <div class=\"option-bg\">\n            <div class=\"option-title\">Buyable?</div>\n            <label class=\"switch\">\n              <input type=\"checkbox\" id=\"buyable\" />\n              <span class=\"slider round\"></span>\n            </label>\n          </div>\n          <div class=\"option-bg\">\n          <div class=\"option-title\">Starting Price</div>\n          <input class=\"option-input\" type=\"number\" id=\"starting-price\" />\n        </div>\n          </div>\n          <div id=\"button-container\">\n            <img id=\"post-button\" src=\"".concat(post_button, "\" />\n          </div>\n        </div>\n      </div>\n    "));
  page.css("\n    #post-button {\n        cursor: pointer;\n    }\n    .option-bg {\n        border-radius: ".concat(display.get("global")["border-radius"][0], ";\n        border: ").concat(display.get("global")["border"], ";\n        height: 30%;\n        width: 80%;\n        display: flex;\n        justify-content: space-between;\n        align-items: center;\n        margin-bottom: 1%;\n    }\n    .option-input {\n        border-bottom: 2px solid ").concat(display.get("text")["color"], ";\n        border-top: none;\n        border-right: none;\n        border-left: none;\n        margin: 5%;\n        position: relative;\n        display: inline-block;\n        width: 60px;\n        height: 34px;\n        background: none;\n        color: ").concat(display.get("text")["color"], ";\n        text-align: left;\n        font-family: ").concat(display.get("text")["font"], ", sans-serif;\n        font-size: ").concat(display.get("text")["size"][1], ";\n        font-style: normal;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        line-height: normal;\n    }\n    .option-title {\n        margin: 5%;\n        color: ").concat(display.get("text")["color"], ";\n        font-family: ").concat(display.get("text")["font"], ", sans-serif;\n        font-size: ").concat(display.get("text")["size"][2], ";\n        font-style: normal;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        line-height: normal;\n    }\n    #char-count {\n        color: ").concat(display.get("text")["color"], ";\n        font-family: ").concat(display.get("text")["font"], ", sans-serif;\n        font-size: ").concat(display.get("text")["size"][0], ";\n        font-style: normal;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        line-height: normal;\n        width: 100%;\n        text-align: center;\n    }\n    #option-container {\n        height: 30%;\n        width: 100%;\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        flex-direction: column;\n    }\n    #container {\n        width: 100%;\n        height: 100%;\n        top: 0;\n        left: 0;\n        position: fixed;\n        display: flex;\n        justify-content: center;\n        align-items: center;\n    }\n\n    .switch {\n        margin: 5%;\n        position: relative;\n        display: inline-block;\n        width: 60px;\n        height: 34px;\n    }\n    \n    .switch input {\n        opacity: 0;\n        width: 0;\n        height: 0;\n    }\n    \n    .slider {\n        position: absolute;\n        cursor: pointer;\n        top: 0;\n        left: 0;\n        right: 0;\n        bottom: 0;\n        background-color: #ccc; /* Updated to use global background color */\n        transition: .4s;\n    }\n    \n    .slider:before {\n        position: absolute;\n        content: \"\";\n        height: 26px;\n        width: 26px;\n        left: 4px;\n        bottom: 4px;\n        background-color: white; /* Updated to use text color */\n        transition: .4s;\n    }\n    \n    input:checked + .slider {\n        background-color: #2196F3;\n    }\n    \n    input:focus + .slider {\n        box-shadow: 0 0 1px #2196F3;\n    }\n    \n    input:checked + .slider:before {\n        transform: translateX(26px);\n    }\n    \n    .slider.round {\n        border-radius: 34px;\n    }\n    \n    .slider.round:before {\n        border-radius: 50%;\n    }\n\n    #new-container {\n        width: 60%;\n        height: 70%;\n        border-radius: ").concat(display.get("global")["border-radius"][0], ";\n        border: ").concat(display.get("global")["border"], ";\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        flex-direction: column;\n    }\n\n    #new-input {\n        width: 80%;\n        height: 30%;\n        border-radius: ").concat(display.get("global")["border-radius"][1], ";\n        border: ").concat(display.get("global")["border"], ";\n        background: none;\n        display: flex;\n        align-items: center;\n        justify-content: start;\n        flex-direction: column;\n        margin: 4%;\n        overflow: auto;\n    }\n\n    [contenteditable=true]:empty:before {\n        content: attr(placeholder);\n        pointer-events: none;\n        display: block; /* For Firefox */\n    }\n\n    #new-input-para {\n        width: 100%;\n        outline: none;\n        vertical-align: top;\n        text-align: center;\n        color: ").concat(display.get("text")["color"], ";\n        font-family: ").concat(display.get("text")["font"], ", sans-serif;\n        font-size: ").concat(display.get("text")["size"][2], ";\n        font-style: normal;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        line-height: normal;\n    }\n\n    ::placeholder {\n        color: ").concat(display.get("text")["color"], ";\n    }\n\n    #button-container {\n        margin: 4%;\n        width: 80%;\n        display: flex;\n        justify-content: flex-end;\n        align-items: center;\n    }\n"));
  function on_render() {
    var editableDiv = document.getElementById('new-input-para');
    var maxLength = parseInt(editableDiv.getAttribute('maxlength'));
    document.getElementById("post-button").onclick = function () {
      grecaptcha.ready(function () {
        grecaptcha.execute('6Lf1n4IoAAAAAEXFEel1BfkxHrcuzJUJNfPiFA3q', {
          action: 'submit'
        }).then(function (token) {
          CreatePost(editableDiv.innerText, document.getElementById("buyable").checked, document.getElementById("starting-price").value, token).then(function (success) {
            if (success) {
              router.navigateTo("/explore");
            } else {
              Notification(1, success);
            }
          });
        });
      });
    };
    editableDiv.addEventListener('input', function (event) {
      var text = this.innerText;
      var cursorPosition = getCaretPosition(this);
      document.getElementById("char-count").innerText = text.length + "/250";
      if (text.length > maxLength) {
        event.preventDefault();
        var truncatedText = text.substring(0, maxLength);
        this.innerText = truncatedText;
        setCaretPosition(this, Math.min(cursorPosition, maxLength));
      }
    });
    function getCaretPosition(element) {
      var sel = window.getSelection();
      return sel.anchorOffset;
    }
    function setCaretPosition(element, position) {
      var range = document.createRange();
      var sel = window.getSelection();
      range.setStart(element.childNodes[0], position);
      range.collapse(true);
      sel.removeAllRanges();
      sel.addRange(range);
    }
  }
  ;
  page.delete_animation("\n    @keyframes delete {\n        0% {\n          opacity: 1;\n          transform: translateY(0%);\n        }\n        100% {\n          opacity: 0;\n          transform: translateY(10%); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.on_render(on_render);
  page.render();
}

},{"../elements/background.mjs":2,"../elements/fonts.mjs":4,"../elements/navbar.mjs":6,"../elements/notifications.mjs":8,"../lib/Framework.mjs":10,"../scripts/api.mjs":29}],23:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Post = Post;
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }
function Post(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page,
    Display = _require.Display;
  var _require2 = require("../elements/fonts.mjs"),
    Fonts = _require2.Fonts;
  var _require3 = require("../elements/background.mjs"),
    Background = _require3.Background;
  var _require4 = require("../elements/navbar.mjs"),
    Navbar = _require4.Navbar;
  var _require5 = require("../elements/post.mjs"),
    Post = _require5.Post;
  var _require6 = require("../scripts/api.mjs"),
    IsLogedIn = _require6.IsLogedIn,
    GetComments = _require6.GetComments;
  var _require7 = require("../elements/notifications.mjs"),
    Notification = _require7.Notification;
  var _require8 = require("../elements/new_post_button.mjs"),
    NewPostButton = _require8.NewPostButton;
  var _require9 = require("../elements/comment.mjs"),
    Comment = _require9.Comment;
  var display = new Display();
  var page = new Page("Post");
  page.clear(["background", "navbar", "fonts", "new_post_button"]);
  Fonts(router);
  Background(router);
  Navbar(router);
  NewPostButton(router);
  page.html("\n    <div id=\"comment-container\" />\n        <div id=\"post-container-single\"> </div>\n        <div class=\"title\">Comments <div id=\"new-button\"><span class=\"material-symbols-outlined\">add</span> New Comment </div> </div>\n        <div id=\"comment-container\"></div>\n    </div>\n    ");
  page.css("\n    #global-container {\n        display: flex;\n        justify-content: start;\n        align-items: center;\n        flex-direction: column;\n        position: absolute;\n        left: 0;\n        width: 100%;\n        height: fit-content;\n    }\n    .title {\n        font-family: ".concat(display.get("text")["font"], ", sans-serif;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        color: ").concat(display.get("text")["color"], ";\n        font-size: ").concat(display.get("text")["size"][2], "; /* Adjust font size */\n        width: 60%;\n    }\n\n    #post-container-single {\n        margin-top: 7.5%;\n        width: 100%;\n        height: fit-content;\n        display: flex;\n        justify-content: start;\n        align-items: center;\n        flex-direction: column;\n    }\n\n    #post-container-single post {\n        width: 60%;\n        height: fit-content;\n        min-height: 5%;\n        margin: 1%;\n    }\n\n    #comment-container {\n        width: 100%;\n        height: fit-content;\n        display: flex;\n        justify-content: start;\n        align-items: center;\n        flex-direction: column;\n    }\n\n    #comment-container comment {\n        width: 60%;\n        height: fit-content;\n        min-height: 5%;\n        margin-top: 1%;\n    }\n\n    #new-button {\n        cursor: pointer;\n        transition-duration: 0.5s;\n        font-family: ").concat(display.get("text")["font"], ", sans-serif;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        font-size: ").concat(display.get("text")["size"][1], "; /* Adjust font size */\n        color: ").concat(display.get("text")["color"], ";\n        height: auto;\n        width: auto;\n        text-align: center;\n        width: fit-content;\n    }\n    #new-button:hover {\n        font-size: ").concat(parseInt(display.get("text")["size"][2]) + 2, "px; /* Increase font size on hover */\n    }\n"));
  function on_render() {
    var api_url = "wss://api.blockcoin.social";
    if (window.location.hostname == "127.0.0.1" || window.location.hostname == "localhost") {
      api_url = "ws://127.0.0.1:8080";
    }
    var socket = null;
    var cache = null;
    var post_id = window.location.pathname.split("/")[2];
    document.getElementById("new-button").onclick = function () {
      router.navigateTo("/comment/" + post_id);
    };
    socket = new WebSocket(api_url + '/post');
    socket.addEventListener('message', function (event) {
      var data = JSON.parse(event.data);
      cache = data;
    });
    function waitForNonNullCache() {
      var interval = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 100;
      return new Promise(function (resolve) {
        function checkVariable() {
          cache;
          if (cache !== null) {
            resolve(cache);
          } else {
            setTimeout(checkVariable, interval);
          }
        }
        checkVariable();
      });
    }
    socket.addEventListener('open', function (event) {
      socket.send(JSON.stringify({
        'opcode': 1,
        "id": post_id
      }));
    });
    waitForNonNullCache().then(function (value) {
      var post = value;
      if (value["success"] != true) {
        Notification(1, "Unknown Post");
        router.navigateTo("/explore");
        return "";
      }
      var post_data = post["data"];
      post_data["user-id"] = post["profile"]["id"];
      post_data["user"] = post["profile"]["display"];
      post_data["profile-picture"] = post["profile"]["profile-picture"];
      post_data["badges"] = post["profile"]["badges"];
      var new_post = new Post(router, post_data, document.getElementById("post-container-single"));
    });
    var post_hierarcy = {}; //Ig that's how you write it i'm not sure about it tbh but i'm gonna let it like that for now

    function add_all_comments_for_key(key) {
      //a bit long I have to admit lol
      if (key in post_hierarcy) {
        for (var comment in post_hierarcy[key]) {
          var parent = "comment-container";
          if (key != "/") {
            parent = key + "-container";
          }
          console.log(parent);
          console.log(post_hierarcy[key][comment]);
          var new_comment = new Comment(router, post_hierarcy[key][comment], document.getElementById(parent), post_id);
          add_all_comments_for_key(post_hierarcy[key][comment]["id"]);
        }
      }
    }
    GetComments(post_id).then(function (data) {
      for (var _i = 0, _Object$entries = Object.entries(data); _i < _Object$entries.length; _i++) {
        var _Object$entries$_i = _slicedToArray(_Object$entries[_i], 2),
          key = _Object$entries$_i[0],
          value = _Object$entries$_i[1];
        console.log(value);
        if (value["parent"] in post_hierarcy) {
          post_hierarcy[value["parent"]].push(value);
        } else {
          post_hierarcy[value["parent"]] = [value];
        }
      }
      console.log(post_hierarcy);
      add_all_comments_for_key("/");
      //const new_comment = new Comment(router,value,document.getElementById("comment-container"))
    });
  }
  page.delete_animation("\n    @keyframes delete {\n        0% {\n          opacity: 1;\n          transform: translateY(0%);\n        }\n        100% {\n          opacity: 0;\n          transform: translateY(10%); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  function on_delete() {
    socket.close();
  }
  page.on_delete(on_delete);
  page.on_render(on_render);
  page.render();
}

},{"../elements/background.mjs":2,"../elements/comment.mjs":3,"../elements/fonts.mjs":4,"../elements/navbar.mjs":6,"../elements/new_post_button.mjs":7,"../elements/notifications.mjs":8,"../elements/post.mjs":9,"../lib/Framework.mjs":10,"../scripts/api.mjs":29}],24:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Profile = Profile;
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }
function Profile(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page,
    Display = _require.Display;
  var _require2 = require("../elements/fonts.mjs"),
    Fonts = _require2.Fonts;
  var _require3 = require("../elements/background.mjs"),
    Background = _require3.Background;
  var _require4 = require("../elements/navbar.mjs"),
    Navbar = _require4.Navbar;
  var _require5 = require("../elements/footer.mjs"),
    Footer = _require5.Footer;
  var _require6 = require("../elements/post.mjs"),
    Post = _require6.Post;
  var _require7 = require("../scripts/api.mjs"),
    GetProfile = _require7.GetProfile,
    FollowUser = _require7.FollowUser,
    FollowedUser = _require7.FollowedUser;
  var _require8 = require("../elements/notifications.mjs"),
    Notification = _require8.Notification;
  var _require9 = require("../elements/new_post_button.mjs"),
    NewPostButton = _require9.NewPostButton;
  var _require10 = require("../scripts/cookies.mjs"),
    setCookie = _require10.setCookie,
    getCookie = _require10.getCookie,
    checkCookie = _require10.checkCookie;
  var display = new Display();
  var page = new Page("Profile");
  page.clear(["background", "navbar", "fonts", "new_post_button"]);
  Fonts(router);
  Background(router);
  Navbar(router);
  NewPostButton(router);
  var border = page.image("border.svg");
  var mockup = page.image("Mockup.png");
  var mockupfront = page.image("MockupFront.png");
  page.html("\n      <img id=\"banner\" />\n      <div id=\"banner-container\">\n        <div class=\"banrr left\">\n          <img id=\"profile-pic\"> </img>\n          <div id=\"username\">Loading...</div>\n          <div id=\"badges-container\"></div>\n        </div>\n        <div class=\"banrr right\">\n          <div id=\"follower-count\">Followers - <span id=\"follower-count-int\"></span></div>\n          <div id=\"follow-button\"> Follow </div>\n        </div>\n      </div>\n      <div class=\"big-container\">\n        <div id=\"button-container\">\n          <div id=\"popular\" class=\"button strong\">Most Popular</div>\n          <div id=\"buyed\" class=\"button\">Bought Posts</div>\n        </div>\n      </div>\n      <div id=\"description\">Loading...</div>\n      <div id=\"post-container\"></div>\n    ");
  page.css("\n    #description {\n      position: absolute;\n      width: 60%;\n      left: 20%;\n      top: 35%;\n      font-family: ".concat(display.get("text")["font"], ", sans-serif;\n      font-weight: ").concat(display.get("text")["font-weight"], ";\n      font-size: ").concat(display.get("text")["size"][1], "; /* Adjust font size */\n      color: ").concat(display.get("text")["color"], ";\n    }\n    #post-container {\n      top: 42%;\n      position: absolute;\n      min-height: 50%;\n      width: 100%;\n      height: fit-content;\n      left: 0;\n      display: flex;\n      justify-content: start;\n      align-items: center;\n      flex-direction: column;\n    }\n\n    #post-container post {\n      width: 60%;\n      height: fit-content;\n      min-height: 5%;\n      margin: 1%;\n    }\n    .big-container {\n      width: 100%;\n      position: absolute;\n      top: 39%;\n      left: 0;\n      display: flex;\n      flex-direction: row;\n      justify-content: center;\n      align-items: center;   \n    }\n    #button-container {\n      width: 60%;\n      display: flex;\n      flex-direction: row;\n      justify-content: flex-start;\n      align-items: center;  \n    }\n    .button {\n      font-family: ").concat(display.get("text")["font"], ", sans-serif;\n      font-weight: ").concat(display.get("text")["font-weight"], ";\n      font-size: ").concat(display.get("text")["size"][1], "; /* Adjust font size */\n      color: ").concat(display.get("text")["color"], ";\n      margin-right: 5%;\n      cursor: pointer;\n    }\n    .strong {\n      font-weight: 600;\n    }\n    .badge {\n      font-size: 50px;\n      color: ").concat(display.get("text")["color"], "; /* Use text color for badge */\n    }\n    #badges-container {\n      width: 20%;\n      display: flex;\n      flex-direction: row;\n      justify-content: flex-start;\n      align-items: center;\n      margin: 1%;\n    }\n    #profile-pic {\n      height: auto;\n      display: block;\n      width: 20%;\n      object-fit: cover;\n      border-radius: 256px;\n    }\n    .right {\n      justify-content: flex-end;\n      margin-right: 10.8%;\n    }\n    .left {\n      justify-content: flex-start;\n      margin-left: 10.8%;\n    }\n    #username {\n      font-family: ").concat(display.get("text")["font"], ", sans-serif;\n      font-weight: ").concat(display.get("text")["font-weight"], ";\n      font-size: ").concat(display.get("text")["size"][3], "; /* Adjust font size */\n      left: 20%;\n      color: ").concat(display.get("text")["color"], ";\n      margin-left: 3%;\n      margin-right: 1%;\n    }\n    #follower-count {\n      font-family: ").concat(display.get("text")["font"], ", sans-serif;\n      font-weight: ").concat(display.get("text")["font-weight"], ";\n      font-size: ").concat(display.get("text")["size"][2], "; /* Adjust font size */\n      color: ").concat(display.get("text")["color"], ";\n      margin: 3%;\n    }\n    #follow-button {\n      cursor: pointer;\n      transition-duration: 0.5s;\n      font-family: ").concat(display.get("text")["font"], ", sans-serif;\n      font-weight: ").concat(display.get("text")["font-weight"], ";\n      font-size: ").concat(display.get("text")["size"][2], "; /* Adjust font size */\n      color: ").concat(display.get("text")["color"], ";\n      border-radius: ").concat(display.get("global")["border-radius"][0], "; /* Use global border radius */\n      border: ").concat(display.get("global")["border"], "; /* Use global border */\n      height: auto;\n      width: auto;\n      text-align: center;\n    }\n    #follow-button:hover {\n      font-size: ").concat(parseInt(display.get("text")["size"][2]) + 2, "px; /* Increase font size on hover */\n    }\n    #banner {\n      top: 7.5%;\n      height: auto;\n      width: 100%;\n      max-height: 20%;\n      object-fit: cover;\n      left: 0;\n      position: absolute;\n    }\n    .banrr {\n      display: flex;\n      width: 30%;\n      flex-direction: row;\n      align-items: center;\n    }\n    #banner-container {\n      left: 0;\n      position: absolute;\n      top: 32%;\n      display: flex;\n      justify-content: space-between;\n      align-items: center;\n      width: 100%;\n      flex-direction: row;\n      height: 0;\n    }\n"));
  page.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  var api_url = "wss://api.blockcoin.social";
  if (window.location.hostname == "127.0.0.1" || window.location.hostname == "localhost") {
    api_url = "ws://127.0.0.1:8080";
  }
  var socket = null;
  function on_render() {
    var cache = null;
    var offset = 0;
    var opcode = 3;
    var followed = false;
    var user = window.location.pathname.split("/")[2];
    if (user == getCookie("v1-id")) {
      document.getElementById("follow-button").innerText = "Edit";
      document.getElementById("follow-button").onclick = function () {
        router.navigateTo("/settings/profile");
      };
    } else {
      FollowedUser(user).then(function (data) {
        followed = data["followed"];
        if (data["followed"]) {
          document.getElementById("follow-button").innerText = "Unfollow";
        }
      });
      document.getElementById("follow-button").onclick = function () {
        grecaptcha.ready(function () {
          grecaptcha.execute('6Lf1n4IoAAAAAEXFEel1BfkxHrcuzJUJNfPiFA3q', {
            action: 'submit'
          }).then(function (token) {
            FollowUser(user, token);
            if (followed) {
              followed = false;
              document.getElementById("follow-button").innerText = "Follow";
              document.getElementById("follower-count-int").innerText = parseInt(document.getElementById("follower-count-int").innerText) - 1;
            } else {
              followed = true;
              document.getElementById("follow-button").innerText = "Unfollow";
              document.getElementById("follower-count-int").innerText = parseInt(document.getElementById("follower-count-int").innerText) + 1;
            }
          });
        });
      };
    }
    GetProfile(user).then(function (profile) {
      if (profile == false) {
        Notification(1, "Unknown User.");
        router.navigateTo("/explore");
        return "";
      }
      document.getElementById("username").innerText = profile["display"];
      document.getElementById("follower-count-int").innerText = profile["followers"];
      document.getElementById("profile-pic").src = profile["profile-picture"];
      document.getElementById("banner").src = profile["banner"];
      document.getElementById("description").innerText = profile["about"];
      var container = document.getElementById("badges-container");
      var badges = ["award_star", "verified", "shield_person", "smart_toy", "local_fire_department", "science", 'bug_report'];
      var titles = ["BlockCoin Admin", "Verified Account", "BlockCoin Staff", "Bot Account", "BlockCoin Premium", "Beta Tester", "Bug Report"];
      for (var i = 0; i < profile["badges"].length; i++) {
        var span = document.createElement("span");
        span.className = "material-symbols-outlined badge";
        span.innerHTML = badges[profile["badges"][i]];
        span.title = titles[profile["badges"][i]];
        // Append the span element to the container div
        container.appendChild(span);
      }
    });
    socket = new WebSocket(api_url + '/post');
    function clearPosts() {
      document.getElementById("post-container").innerHTML = "";
    }
    function removeStrong() {
      var elements = page.document.getElementsByClassName('strong');
      var elementsArray = Array.from(elements);
      elementsArray.forEach(function (element) {
        element.classList.remove('strong');
      });
    }
    function waitForNonNullCache() {
      var interval = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 100;
      return new Promise(function (resolve) {
        function checkVariable() {
          cache;
          if (cache !== null) {
            resolve(cache);
          } else {
            setTimeout(checkVariable, interval);
          }
        }
        checkVariable();
      });
    }
    function parsecache() {
      if (cache != null) {
        if (cache["opcode"] == opcode) {
          for (var _i = 0, _Object$entries = Object.entries(cache["data"]); _i < _Object$entries.length; _i++) {
            var _Object$entries$_i = _slicedToArray(_Object$entries[_i], 2),
              key = _Object$entries$_i[0],
              value = _Object$entries$_i[1];
            try {
              var post = value;
              var post_data = post["data"];
              post_data["user-id"] = post["profile"]["id"];
              post_data["user"] = post["profile"]["display"];
              post_data["profile-picture"] = post["profile"]["profile-picture"];
              post_data["badges"] = post["profile"]["badges"];
              var new_post = new Post(router, post_data, document.getElementById("post-container"));
            } catch (_unused) {}
          }
        }
      }
    }
    socket.addEventListener('message', function (event) {
      var data = JSON.parse(event.data);
      cache = data;
      parsecache();
    });
    socket.addEventListener('close', function (event) {
      socket = new WebSocket(api_url + '/post');
    });
    socket.addEventListener('open', function (event) {
      socket.send(JSON.stringify({
        'opcode': opcode,
        'offset': offset,
        "user": user
      }));
      offset++;
      socket.send(JSON.stringify({
        'opcode': opcode,
        'offset': offset,
        "user": user
      }));
      offset++;
      waitForNonNullCache().then(function (value) {
        parsecache();
      });
    });
    document.getElementById("buyed").onclick = function () {
      if (opcode == 4) {
        return "";
      }
      offset = 0;
      opcode = 4;
      cache = null;
      socket.send(JSON.stringify({
        'opcode': opcode,
        'offset': offset,
        "user": user
      }));
      offset++;
      socket.send(JSON.stringify({
        'opcode': opcode,
        'offset': offset,
        "user": user
      }));
      offset++;
      removeStrong();
      document.getElementById("buyed").classList.add('strong');
      waitForNonNullCache().then(function (value) {
        clearPosts();
        parsecache();
      });
    };
    document.getElementById("popular").onclick = function () {
      if (opcode == 3) {
        return "";
      }
      offset = 0;
      opcode = 3;
      cache = null;
      socket.send(JSON.stringify({
        'opcode': opcode,
        'offset': offset,
        "user": user
      }));
      offset++;
      socket.send(JSON.stringify({
        'opcode': opcode,
        'offset': offset,
        "user": user
      }));
      offset++;
      removeStrong();
      document.getElementById("popular").classList.add('strong');
      waitForNonNullCache().then(function (value) {
        clearPosts();
        parsecache();
      });
    };
    window.onscroll = function () {
      var scrollHeight = document.documentElement.scrollHeight;
      var scrollTop = window.pageYOffset !== undefined ? window.pageYOffset : (document.documentElement || document.body.parentNode || document.body).scrollTop;
      var windowHeight = window.innerHeight;
      if (scrollTop + windowHeight >= scrollHeight) {
        socket.send(JSON.stringify({
          'opcode': opcode,
          'offset': offset,
          "user": user
        }));
        offset++;
        parsecache();
      }
    };
  }
  page.on_render(on_render);
  page.render();
}

},{"../elements/background.mjs":2,"../elements/fonts.mjs":4,"../elements/footer.mjs":5,"../elements/navbar.mjs":6,"../elements/new_post_button.mjs":7,"../elements/notifications.mjs":8,"../elements/post.mjs":9,"../lib/Framework.mjs":10,"../scripts/api.mjs":29,"../scripts/cookies.mjs":30}],25:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Redirect = Redirect;
function Redirect(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page;
  var page = new Page("Redirect");
  var links = {
    "/status": "https://blockcoin.betteruptime.com/",
    "/discord": "https://discord.gg/DNkyyC4hsh",
    "/api": "https://api.blockcoin.social",
    "/twitter": "https://twitter.com/blockcoin0",
    "/scratch": "https://scratch.mit.edu/projects/824613252/",
    "/docs": "https://docs.blockcoin.herasium.dev/docs/intro"
  };
  page.html("");
  page.css('');
  function on_render() {
    window.location.replace(links[window.location.pathname]);
  }
  page.on_render(on_render);
  page.render();
}

},{"../lib/Framework.mjs":10}],26:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Register = Register;
function Register(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page,
    Display = _require.Display;
  var _require2 = require("../elements/fonts.mjs"),
    Fonts = _require2.Fonts;
  var _require3 = require("../elements/background.mjs"),
    Background = _require3.Background;
  var _require4 = require("../elements/navbar.mjs"),
    Navbar = _require4.Navbar;
  var _require5 = require("../elements/footer.mjs"),
    Footer = _require5.Footer;
  var _require6 = require("../scripts/api.mjs"),
    Register = _require6.Register;
  var _require7 = require("../elements/notifications.mjs"),
    Notification = _require7.Notification;
  var display = new Display();
  var page = new Page("Register");
  var blank_logo = page.image("logo_blank.svg");
  var register_button = page.image("register_button.svg");
  page.clear(["background", "navbar", "fonts", "footer"]);
  Fonts(router);
  Background(router);
  Navbar(router);
  Footer(router);
  page.html("\n    <div class=\"container\">\n        <img src=\"".concat(blank_logo, "\" alt=\"A white version of the blockcoin logo\"></img>\n        <div class=\"text\">Write, Post, Earn.</div>\n    </div>\n    <div class=\"container-2\">\n        <div class=\"text small\">Register</div>\n        <div class=\"form\">\n            <span class=\"material-symbols-outlined\">account_circle</span>\n            <input placeholder=\"Username\" id=\"username\" type=\"text\"></input>\n        </div>\n        <div class=\"form\">\n            <span class=\"material-symbols-outlined\">mail</span>\n            <input placeholder=\"E-Mail\" id=\"contact\" type=\"email\"></input>\n        </div>\n        <div class=\"form\">\n            <span class=\"material-symbols-outlined\">password</span>\n            <input placeholder=\"Password\" id=\"password\" type=\"password\"></input>\n        </div>\n        <img src=\"").concat(register_button, "\" alt=\"The register button\" id=\"Register\"></img>\n        <button id=\"Login\">Or Login</button>\n        <div class=\"text very-small\">By clicking 'Register', you agree with BlockCoin's\n        <a id=\"policy\" class=\"g-link\">Privacy Policy</a> and\n        <a id=\"tos\" class=\"g-link\">Terms of Service</a>.</div>\n        <div class=\"text very-small\">This site is protected by reCAPTCHA. <br>The Google\n        <a href=\"https://policies.google.com/privacy\" class=\"g-link\">Privacy Policy</a> and\n        <a href=\"https://policies.google.com/terms\" class=\"g-link\">Terms of Service</a> apply.</div>\n    </div>\n    "));
  page.css("\n    .g-link {\n        color: ".concat(display.get("text")["color"], ";\n        text-decoration: underline ").concat(display.get("text")["color"], ";\n        cursor:pointer;\n    } \n\n    .text {\n        font-family: ").concat(display.get("text")["font"], ", sans-serif;\n        font-weight: ").concat(display.get("text")["font-weight-bold"], ";\n        font-size: ").concat(display.get("text")["size"][4], "; /* Adjust font size */\n        color: ").concat(display.get("text")["color"], ";\n    }\n    \n    .small {\n        font-weight: ").concat(display.get("text")["font-weight-light"], ";\n        font-size: ").concat(display.get("text")["size"][1], ";\n    }\n    \n    .very-small {\n        margin:1%;\n        text-align: center;\n        font-size: ").concat(display.get("text")["size"][0], ";\n        font-weight: ").concat(display.get("text")["font-weight-light"], ";\n    }\n\n    .container {\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        flex-direction: column;\n        top:0;\n        left:0;\n        height: 100%;\n        width: 50%;\n        position: absolute;\n        z-index: ").concat(display.get("global")["z-index"][0], "; /* Adjust z-index */\n        gap: 10px;\n    }\n    \n    ::-webkit-scrollbar {\n        width: 10px;\n    }\n    \n    ::-webkit-scrollbar-track {\n        background: none;\n    }\n    \n    ::-webkit-scrollbar-thumb {\n        background: ").concat(display.get("text")["color"], "; /* Adjust scrollbar color */\n        border-radius: 360px;\n    }\n    \n    ::-webkit-scrollbar-thumb:hover {\n        background: #555;\n    }\n    \n    .container-2 {\n        overflow: hidden;\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        flex-direction: column;\n        top:0;\n        right:0;\n        height: 100%;\n        width: 50%;\n        position: absolute;\n        z-index: ").concat(display.get("global")["z-index"][0], "; /* Adjust z-index */\n    }\n    \n    #button {\n        border-radius: ").concat(display.get("global")["border-radius"][2], "; /* Adjust border radius */\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        font-family: ").concat(display.get("text")["font"], ", sans-serif;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        color: ").concat(display.get("text")["color"], ";\n        font-size: ").concat(display.get("text")["size"][3], ";\n        background: url(border.svg);\n        border: none;\n        box-shadow: none;\n        cursor: pointer;\n        width: 360px;\n        height: 70px;\n    }\n    \n    .form {\n        width: 375px;\n        height: 55px;\n        border-bottom: 1px solid ").concat(display.get("text")["color"], "; /* Adjust border color */\n        display: flex;\n        justify-content: space-between;\n        align-items: center;\n    }\n    \n    .form span{\n        color: ").concat(display.get("text")["color"], ";\n        font-size: ").concat(display.get("text")["size"][3], ";\n    }\n    \n    .form input{\n        background: none;\n        text-align: right;\n        color: ").concat(display.get("text")["color"], ";\n        height: 100%;\n        border: none;\n        font-size: ").concat(display.get("text")["size"][1], ";\n        width: 80%;\n    }\n    \n    .form input:focus {\n        outline:none!important;\n    }\n    \n    ::placeholder {\n        color: ").concat(display.get("text")["color"], ";\n    }\n    \n    p{\n        color: ").concat(display.get("text")["color"], ";\n    }\n    \n    #Register {\n        cursor: pointer;\n        margin-top: 30px;\n        border: none;\n        width: 330px;\n        height: 53px;\n    }\n    \n    #Login {\n        cursor: pointer;\n        background: none;\n        border: none;\n        font-family: ").concat(display.get("text")["font"], ", sans-serif;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        color: ").concat(display.get("text")["color"], ";\n        font-size: ").concat(display.get("text")["size"][2], ";\n        margin-top: 5px;\n    }\n    \n    #mockup {\n        content: url(Mockup3.png);\n    }\n    \n    @media screen and (max-width: 1270px){\n        #mockup {\n            content: url(MockupFront.png);\n        }\n        .container {\n            display: none;\n            width: 100%; \n            height: 100%;\n        }\n        .container-2 {\n            width:100%;\n        }\n        footer {\n            position:absolute;\n            top:150%;\n        }\n        #copy {\n            top:100%\n        }\n        .elipse {\n            height: 48vw;\n            width: 48vw;\n        }\n    }\n    \n    @media screen and (max-width: 650px){\n        .big {\n            font-size: 10.7vw;\n        }\n        .small {\n            font-size: 4.6vw;\n        }\n    }\n    \n    @media screen and (max-width: 550px){\n        #navbar {\n            display: flex;\n            justify-content: center;\n            align-items: center;\n            position: absolute;\n            flex-direction: column;\n            margin-top: 20px;\n        }\n        .container-3 {\n            display: flex;\n            justify-content: space-around;\n            align-items: center;\n            width: 100%;\n        }\n        .trans-button {\n            width: 30%;\n            text-align: center;\n        }\n        #copy {\n            margin: 0;\n            top:0;\n            width:100%;\n            left:0;\n            text-align: center;\n        }\n        .container-links {\n            width: 100%;\n            margin-bottom: 0px;\n        }\n        .container-titles {\n            width: 100%;\n            margin-bottom: 0px;\n        }\n        footer {\n            overflow: hidden;\n            height: 20%;\n        }\n        .container-4{\n            position: absolute;\n            bottom: 30%;\n        }\n    }\n"));
  page.delete_animation("\n    @keyframes delete {\n        0% {\n          opacity: 1;\n          transform: translateY(0%);\n        }\n        100% {\n          opacity: 0;\n          transform: translateY(10%); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  function on_render() {
    document.getElementById("Login").onclick = function () {
      router.navigateTo("/login");
    };
    document.getElementById("policy").onclick = function () {
      router.navigateTo("/legal/policy");
    };
    document.getElementById("tos").onclick = function () {
      router.navigateTo("/legal/tos");
    };
    document.getElementById("Register").onclick = function () {
      grecaptcha.ready(function () {
        grecaptcha.execute('6Lf1n4IoAAAAAEXFEel1BfkxHrcuzJUJNfPiFA3q', {
          action: 'submit'
        }).then(function (token) {
          Register(document.getElementById('username').value, document.getElementById('contact').value, document.getElementById('password').value, token).then(function (success) {
            if (success == true) {
              router.navigateTo("/explore");
            } else {
              Notification(1, success);
            }
          })["catch"](function (error) {
            console.error("Error during registration:", error);
          });
        });
      });
    };
  }
  page.on_render(on_render);
  page.render();
}

},{"../elements/background.mjs":2,"../elements/fonts.mjs":4,"../elements/footer.mjs":5,"../elements/navbar.mjs":6,"../elements/notifications.mjs":8,"../lib/Framework.mjs":10,"../scripts/api.mjs":29}],27:[function(require,module,exports){
"use strict";

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Settings = Settings;
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == _typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator["return"] && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, "catch": function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function Settings(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page,
    Display = _require.Display;
  var _require2 = require("../elements/fonts.mjs"),
    Fonts = _require2.Fonts;
  var _require3 = require("../elements/background.mjs"),
    Background = _require3.Background;
  var _require4 = require("../elements/navbar.mjs"),
    Navbar = _require4.Navbar;
  var _require5 = require("../elements/post.mjs"),
    Post = _require5.Post;
  var _require6 = require("../scripts/api.mjs"),
    IsLogedIn = _require6.IsLogedIn,
    UpdateAbout = _require6.UpdateAbout,
    UpdateBanner = _require6.UpdateBanner,
    UpdateDisplay = _require6.UpdateDisplay,
    UpdateEmail = _require6.UpdateEmail,
    UpdatePassword = _require6.UpdatePassword,
    UpdateProfilePicture = _require6.UpdateProfilePicture,
    GetProfile = _require6.GetProfile;
  var _require7 = require("../elements/notifications.mjs"),
    Notification = _require7.Notification;
  var _require8 = require("../elements/new_post_button.mjs"),
    NewPostButton = _require8.NewPostButton;
  var _require9 = require("../scripts/cookies.mjs"),
    setCookie = _require9.setCookie,
    getCookie = _require9.getCookie,
    checkCookie = _require9.checkCookie;
  if (IsLogedIn() == false) {
    Notification(1, "You need to be logged in to access this page.");
    router.navigateTo("/explore");
    return "";
  }
  var display = new Display();
  var page = new Page("Settings");
  page.clear(["background", "navbar", "fonts", "new_post_button"]);
  Fonts(router);
  Background(router);
  Navbar(router);
  NewPostButton(router);
  page.html("\n      <div id=\"settings-container\">\n        <div class=\"title\">Profile</div>\n        <div class=\"text-settings\">\n          <div class=\"settings-name text-name\">Display Name</div>\n          <input class=\"text-input\"  id=\"display\" ></input>\n          <div class=\"settings-button\" id=\"display-change\" >Save</div>\n        </div>\n        <div class=\"text-settings\">\n          <div class=\"settings-name text-name\">About Me</div>\n          <input class=\"text-input\"  id=\"about\" ></input>\n          <div class=\"settings-button\"  id=\"about-change\"  >Save</div>\n        </div>\n        <div class=\"image-settings\">\n          <div class=\"img-txt\">\n            <div class=\"settings-name img-name\">Profile Picture</div>\n            <div class=\"settings-button\"  id=\"icon-change\"  >Change</div>\n            <input type=\"file\" id=\"fileInput\" accept=\".png,.jpg,.jpeg,.webp\" style=\"display: none;\">\n          </div>\n          <div class=\"img-img\">\n            <img class=\"settings-img\" id=\"pp\" src=\"https://blockcoin.social/assets/logo.png\" />\n          </div>\n        </div>\n        <div class=\"image-settings\">\n        <div class=\"img-txt\">\n          <div class=\"settings-name img-name\">Banner</div>\n          <div class=\"settings-button\"  id=\"banner-change\"  >Change</div>\n          <input type=\"file\" id=\"banner-fileInput\" accept=\".png,.jpg,.jpeg,.webp\" style=\"display: none;\">\n        </div>\n        <div class=\"img-img\">\n          <img class=\"settings-img\" id=\"banner\" src=\"https://blockcoin.social/assets/default_banner.png\" />\n        </div>\n        </div>\n        <div class=\"text-settings\">\n          <div class=\"settings-name text-name\">Theme</div>\n          <input class=\"text-input\"  id=\"theme\" ></input>\n          <div class=\"settings-button\"  id=\"theme-change\"  >Save</div>\n        </div>\n        <div class=\"title\">Security</div>\n        <div class=\"text-settings\">\n          <div class=\"settings-name text-name\">Email</div>\n          <input class=\"text-input\"  id=\"email\"  type=\"email\"></input>\n          <div class=\"settings-button\"  id=\"email-change\"  >Save</div>\n        </div>\n        <div class=\"text-settings\">\n          <div class=\"settings-name text-name\">Password Change</div>\n          <input class=\"text-input\" id=\"new-password\" type=\"password\" placeholder=\"New Password\"></input>\n          <input class=\"text-input\" type=\"password\" id=\"password\" placeholder=\"Current Password\"></input>\n          <div class=\"settings-button\" id=\"password-change\" >Save</div>\n        </div>\n        <div class=\"image-settings\">\n        <div class=\"img-txt\">\n          <div class=\"settings-button\" id=\"disconnect\">Disconnect</div>\n          <div class=\"settings-button\" id=\"delete\">Delete Request</div>\n        </div>\n      </div>\n      </div>\n    ");
  page.css("\n    #delete {\n        margin-bottom: 10px; /* Adjust margin */\n    }\n    \n    #disconnect {\n        margin-bottom:  10px; /* Adjust margin */\n    }\n    \n    .img-name {\n        width:auto;\n    }\n    \n    .image-settings {\n        width: 90%;\n        margin-top: 25px; /* Adjust margin */\n    }\n    \n    .img-txt {\n        display: flex;\n        justify-content: space-between;\n        align-items: center;\n        flex-direction: row;\n        width: 100%;\n    }\n    \n    .img-img {\n        overflow: auto;\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        flex-direction: row;\n        width: 100%;\n    }\n    \n    .settings-button {\n        cursor: pointer;\n        transition-duration: 0.5s;\n        font-family: ".concat(display.get("text")["font"], ", sans-serif;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        font-size: ").concat(display.get("text")["size"][2], "; /* Adjust font size */\n        color: ").concat(display.get("text")["color"], ";\n        border-radius: ").concat(display.get("global")["border-radius"][2], "; /* Adjust border radius */\n        border: ").concat(display.get("global")["border"], "; /* Adjust border color */\n        height: auto;\n        width: auto;\n        text-align: center;\n    }\n    \n    .settings-button:hover {\n        font-size: ").concat(display.get("text")["size"][4], "; /* Adjust font size */\n    }\n    \n    .text-input {\n        padding: 0px 3%;\n        width: 94%;\n        outline: none;\n        background: none;\n        border: ").concat(display.get("global")["border"], "; /* Adjust border color */\n        border-radius: ").concat(display.get("global")["border-radius"][2], "; /* Adjust border radius */\n        min-height:50px; /* Adjust min height */\n        font-family: ").concat(display.get("text")["font"], ", sans-serif;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        color: ").concat(display.get("text")["color"], ";\n        font-size: ").concat(display.get("text")["size"][2], "; /* Adjust font size */\n        text-align: left;\n        margin-bottom: 15px; /* Adjust margin */\n    }\n    \n    #settings-container {\n        margin-bottom: 10px; /* Adjust margin */\n        width: 60%;\n        position: absolute;\n        height: auto;\n        top: 20%;\n        left: 20%;\n        border: ").concat(display.get("global")["border"], "; /* Adjust border */\n        display: flex;\n        border-radius: ").concat(display.get("global")["border-radius"][2], "; /* Adjust border radius */\n        justify-content: flex-start;\n        align-items: center;\n        flex-direction: column;\n    }\n    \n    .title {\n        font-family: ").concat(display.get("text")["font"], ", sans-serif;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        color: ").concat(display.get("text")["color"], ";\n        font-size: ").concat(display.get("text")["size"][4], "; /* Adjust font size */\n        text-align: left;\n        margin-top: 25px; /* Adjust margin */\n        width: 90%;\n    }\n    \n    .text-settings {\n        display: flex;\n        justify-content: flex-end;\n        align-items: flex-end;\n        flex-direction: column;\n        width: 90%;\n        margin-top: 25px; /* Adjust margin */\n    }\n    \n    .settings-name {\n        font-family: ").concat(display.get("text")["font"], ", sans-serif;\n        font-weight: ").concat(display.get("text")["font-weight"], ";\n        color: ").concat(display.get("text")["color"], ";\n        font-size: ").concat(display.get("text")["size"][1], "; /* Adjust font size */\n    }\n    \n    .text-name {\n        text-align: left;\n        width: 100%;\n    }\n"));
  page.delete_animation("\n    @keyframes delete {\n        0% {\n          opacity: 1;\n          transform: translateY(0%);\n        }\n        100% {\n          opacity: 0;\n          transform: translateY(10%); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  function on_render() {
    function refresh_data() {
      GetProfile(getCookie("v1-id")).then(function (data) {
        document.getElementById("display").placeholder = data["display"];
        document.getElementById("theme").placeholder = "Copy and paste your favorite theme json's here !";
        document.getElementById("about").placeholder = data["about"];
        document.getElementById("banner").src = data["banner"];
        document.getElementById("pp").src = data["profile-picture"];
        document.getElementById("email").placeholder = "you@email.bc";
      });
    }
    refresh_data();
    document.getElementById("icon-change").onclick = selectFileIcon;
    function selectFileIcon() {
      var fileInput = document.getElementById('fileInput');
      fileInput.click();
      fileInput.addEventListener('change', handleFileSelectIcon);
    }
    function handleFileSelectIcon(event) {
      var fileInput = event.target;
      var file = fileInput.files[0];
      var reader = new FileReader();
      reader.onload = /*#__PURE__*/_asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var fileContentBase64;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              fileContentBase64 = reader.result.split(',')[1];
              UpdateProfilePicture(fileContentBase64).then(function (data) {
                if (data == false) {
                  Notification(1, "An unknown error happened. Please retry later.");
                } else {
                  Notification(0, data);
                  setCookie("v1-profile-picture", "");
                  refresh_data();
                }
              });
            case 2:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
      reader.readAsDataURL(file);
    }
    document.getElementById("banner-change").onclick = selectFileBanner;
    function selectFileBanner() {
      var fileInput = document.getElementById('banner-fileInput');
      fileInput.click();
      fileInput.addEventListener('change', handleBannerFileSelect);
    }
    function handleBannerFileSelect(event) {
      var fileInput = event.target;
      var file = fileInput.files[0];
      var reader = new FileReader();
      reader.onload = /*#__PURE__*/_asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var fileContentBase64;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              fileContentBase64 = reader.result.split(',')[1];
              UpdateBanner(fileContentBase64).then(function (data) {
                if (data == false) {
                  Notification(1, "An unknown error happened. Please retry later.");
                } else {
                  Notification(0, data);
                  refresh_data();
                }
              });
            case 2:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
      reader.readAsDataURL(file);
    }
    document.getElementById("theme-change").onclick = function () {
      setCookie("v1-theme", document.getElementById("theme").value);
      location.reload();
    };
    document.getElementById("display-change").onclick = function () {
      UpdateDisplay(document.getElementById("display").value).then(function (data) {
        if (data == false) {
          Notification(1, "An unknown error happend. Please retry later.");
        } else {
          Notification(0, data);
          refresh_data();
        }
      });
    };
    document.getElementById("about-change").onclick = function () {
      UpdateAbout(document.getElementById("about").value).then(function (data) {
        if (data == false) {
          Notification(1, "An unknown error happend. Please retry later.");
        } else {
          Notification(0, data);
          refresh_data();
        }
      });
    };
    document.getElementById("email-change").onclick = function () {
      UpdateEmail(document.getElementById("email").value).then(function (data) {
        if (data == false) {
          Notification(1, "An unknown error happend. Please retry later.");
        } else {
          Notification(0, data);
          refresh_data();
        }
      });
    };
    document.getElementById("password-change").onclick = function () {
      UpdatePassword(document.getElementById("password").value, document.getElementById("new-password").value).then(function (data) {
        if (data == false) {
          Notification(1, "An unknown error happend. (Is it really the right password ?)");
        } else {
          Notification(0, data);
          refresh_data();
        }
      });
    };
    document.getElementById("disconnect").onclick = function () {
      setCookie("v1-user", "");
      setCookie("v1-id", "");
      setCookie("v1-token", "");
      setCookie("v1-profile-picture", "");
      router.navigateTo("/");
    };
  }
  page.on_render(on_render);
  page.render();
}

},{"../elements/background.mjs":2,"../elements/fonts.mjs":4,"../elements/navbar.mjs":6,"../elements/new_post_button.mjs":7,"../elements/notifications.mjs":8,"../elements/post.mjs":9,"../lib/Framework.mjs":10,"../scripts/api.mjs":29,"../scripts/cookies.mjs":30}],28:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Trending = Trending;
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }
function Trending(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page;
  var _require2 = require("../elements/fonts.mjs"),
    Fonts = _require2.Fonts;
  var _require3 = require("../elements/background.mjs"),
    Background = _require3.Background;
  var _require4 = require("../elements/navbar.mjs"),
    Navbar = _require4.Navbar;
  var _require5 = require("../elements/post.mjs"),
    Post = _require5.Post;
  var _require6 = require("../scripts/api.mjs"),
    IsLogedIn = _require6.IsLogedIn;
  var _require7 = require("../elements/notifications.mjs"),
    Notification = _require7.Notification;
  var _require8 = require("../elements/new_post_button.mjs"),
    NewPostButton = _require8.NewPostButton;
  var page = new Page("Trending");
  page.clear(["background", "navbar", "fonts", "new_post_button"]);
  Fonts(router);
  Background(router);
  Navbar(router);
  NewPostButton(router);
  page.html("\n    <div id=\"post-container\">\n\n    </div>\n    ");
  page.css("\n\n    #post-container {\n        margin-top: 7.5%;\n        position: absolute;\n        min-height:100%;\n        width:100%;\n        height:fit-content;\n        top:0;\n        left:0;\n        display:flex;\n        justify-content:start;\n        align-items:center;\n        flex-direction:column;\n    }\n\n    #post-container post {\n      width:60%;\n      height:fit-content;\n      min-height: 5%;\n      margin: 1%\n    }\n    ");
  var api_url = "wss://api.blockcoin.social";
  if (window.location.hostname == "127.0.0.1" || window.location.hostname == "localhost") {
    api_url = "ws://127.0.0.1:8080";
  }
  var socket = null;
  function on_render() {
    socket = new WebSocket(api_url + '/post');
    var cache = [];
    function waitForNonNullCache() {
      var interval = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 100;
      return new Promise(function (resolve) {
        function checkVariable() {
          cache;
          if (cache !== null) {
            resolve(cache);
          } else {
            setTimeout(checkVariable, interval);
          }
        }
        checkVariable();
      });
    }
    function parsecache() {
      if (cache != null) {
        if (cache["opcode"] == 5) {
          for (var _i = 0, _Object$entries = Object.entries(cache["data"]); _i < _Object$entries.length; _i++) {
            var _Object$entries$_i = _slicedToArray(_Object$entries[_i], 2),
              key = _Object$entries$_i[0],
              value = _Object$entries$_i[1];
            try {
              var post = value;
              var post_data = post["data"];
              post_data["user-id"] = post["profile"]["id"];
              post_data["user"] = post["profile"]["display"];
              post_data["profile-picture"] = post["profile"]["profile-picture"];
              post_data["badges"] = post["profile"]["badges"];
              var new_post = new Post(router, post_data, document.getElementById("post-container"));
            } catch (e) {
              console.log("Error", e.stack);
              console.log("Error", e.name);
              console.log("Error", e.message);
            }
          }
        }
      }
    }
    socket.addEventListener('message', function (event) {
      var data = JSON.parse(event.data);
      cache = data;
      parsecache();
    });
    socket.addEventListener('close', function (event) {
      socket = new WebSocket(api_url + '/post');
    });
    socket.addEventListener('open', function (event) {
      socket.send(JSON.stringify({
        'opcode': 5,
        'limit': 10
      }));
    });
    window.onscroll = function () {
      var scrollHeight = document.documentElement.scrollHeight;
      var scrollTop = window.pageYOffset !== undefined ? window.pageYOffset : (document.documentElement || document.body.parentNode || document.body).scrollTop;
      var windowHeight = window.innerHeight;
      if (scrollTop + windowHeight >= scrollHeight) {
        socket.send(JSON.stringify({
          'opcode': 2,
          'limit': 20
        }));
        parsecache();
      }
    };
  }
  page.delete_animation("\n    @keyframes delete {\n        0% {\n          opacity: 1;\n          transform: translateY(0%);\n        }\n        100% {\n          opacity: 0;\n          transform: translateY(10%); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  function on_delete() {
    socket.close();
  }
  page.on_delete(on_delete);
  page.on_render(on_render);
  page.render();
}

},{"../elements/background.mjs":2,"../elements/fonts.mjs":4,"../elements/navbar.mjs":6,"../elements/new_post_button.mjs":7,"../elements/notifications.mjs":8,"../elements/post.mjs":9,"../lib/Framework.mjs":10,"../scripts/api.mjs":29}],29:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Balance = Balance;
exports.BuyPost = BuyPost;
exports.CommentLiked = CommentLiked;
exports.CreateComment = CreateComment;
exports.CreatePost = CreatePost;
exports.FollowUser = FollowUser;
exports.FollowedUser = FollowedUser;
exports.GetComments = GetComments;
exports.GetProfile = GetProfile;
exports.IsLogedIn = IsLogedIn;
exports.LikeComment = LikeComment;
exports.LikePost = LikePost;
exports.Login = Login;
exports.PostLiked = PostLiked;
exports.RandomPosts = RandomPosts;
exports.Register = Register;
exports.Stats = Stats;
exports.UpdateAbout = UpdateAbout;
exports.UpdateBanner = UpdateBanner;
exports.UpdateDisplay = UpdateDisplay;
exports.UpdateEmail = UpdateEmail;
exports.UpdatePassword = UpdatePassword;
exports.UpdateProfilePicture = UpdateProfilePicture;
exports.VerifyToken = VerifyToken;
exports.ViewPost = ViewPost;
var _rewriteStackTrace = require("@babel/core/lib/errors/rewrite-stack-trace");
var _require = require("./cookies.mjs"),
  setCookie = _require.setCookie,
  getCookie = _require.getCookie,
  checkCookie = _require.checkCookie;
var api_url = "https://api.blockcoin.social";
if (window.location.hostname == "127.0.0.1" || window.location.hostname == "localhost") {
  api_url = "http://127.0.0.1:8080";
}
function Login(user, password, captcha) {
  var url = api_url + "/user/login";
  var options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      "user": user,
      "password": password,
      "captcha": captcha
    })
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      setCookie("v1-profile-picture", "", 365);
      setCookie("v1-user", data["user"], 365);
      setCookie("v1-id", data["id"], 365);
      setCookie("v1-token", data["token"], 365);
      return true;
    } else {
      return data["message"];
    }
  })["catch"](function (error) {
    return data["message"];
  });
}
function Register(user, contact, password, captcha) {
  var url = api_url + "/user/register";
  var options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      "user": user,
      "password": password,
      "contact": contact,
      "captcha": captcha
    })
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      setCookie("v1-profile-picture", "", 365);
      setCookie("v1-user", data["user"], 365);
      setCookie("v1-id", data["id"], 365);
      setCookie("v1-token", data["token"], 365);
      return true;
    } else {
      return data["message"];
    }
  })["catch"](function (error) {
    return data["message"];
  });
}
function RandomPosts(limit) {
  if (limit > 20) {
    limit = 20;
  }
  var url = api_url + "/social/random?limit=" + limit;
  var options = {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return data["data"];
    } else {
      return false;
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function GetProfile(id) {
  var url = api_url + "/user/profile?user=" + id;
  var options = {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return data["data"];
    } else {
      return false;
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function CreatePost(data, isbuyable, price, captcha) {
  var url = api_url + "/social/post";
  var options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      "user": getCookie("v1-id"),
      "token": getCookie("v1-token"),
      "data": data,
      "isBuyable": isbuyable,
      "price": price,
      "captcha": captcha
    })
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return true;
    } else {
      return data["message"];
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function IsLogedIn() {
  return checkCookie("v1-user") && checkCookie("v1-id") && checkCookie("v1-token");
}
function ViewPost(id) {
  var url = api_url + "/social/view";
  var options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      "user": getCookie("v1-id"),
      "token": getCookie("v1-token"),
      "post": id
    })
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return true;
    } else {
      return false;
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function PostLiked(id) {
  var url = api_url + "/social/liked";
  var options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      "user": getCookie("v1-id"),
      "token": getCookie("v1-token"),
      "post": id
    })
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return data;
    } else {
      return false;
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function LikePost(id) {
  var url = api_url + "/social/like";
  var options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      "user": getCookie("v1-id"),
      "token": getCookie("v1-token"),
      "post": id
    })
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return true;
    } else {
      return false;
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function FollowedUser(id) {
  var url = api_url + "/social/followed";
  var options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      "user": getCookie("v1-id"),
      "token": getCookie("v1-token"),
      "target": id
    })
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return data;
    } else {
      return false;
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function FollowUser(user, captcha) {
  var url = api_url + "/social/follow";
  var options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      "user": getCookie("v1-id"),
      "token": getCookie("v1-token"),
      "captcha": captcha,
      "target": user
    })
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return true;
    } else {
      return false;
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function Balance(user) {
  var url = api_url + "/user/balance?user=" + user;
  var options = {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return data["balance"];
    } else {
      return false;
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function Stats(user) {
  var url = api_url + "/social/stats/user?user=" + user;
  var options = {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return data["data"];
    } else {
      return false;
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function UpdateProfilePicture(file) {
  var url = api_url + "/user/update/profile";
  var options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      "user": getCookie("v1-id"),
      "token": getCookie("v1-token"),
      "picture": file
    })
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return data["message"];
    } else {
      return false;
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function UpdateAbout(about) {
  var url = api_url + "/user/update/profile";
  var options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      "user": getCookie("v1-id"),
      "token": getCookie("v1-token"),
      "about": about
    })
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return data["message"];
    } else {
      return false;
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function UpdateDisplay(file) {
  var url = api_url + "/user/update/profile";
  var options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      "user": getCookie("v1-id"),
      "token": getCookie("v1-token"),
      "display": file
    })
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return data["message"];
    } else {
      return false;
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function UpdateBanner(file) {
  var url = api_url + "/user/update/profile";
  var options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      "user": getCookie("v1-id"),
      "token": getCookie("v1-token"),
      "banner": file
    })
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return data["message"];
    } else {
      return false;
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function UpdateEmail(file) {
  var url = api_url + "/user/update/profile";
  var options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      "user": getCookie("v1-id"),
      "token": getCookie("v1-token"),
      "email": file
    })
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return data["message"];
    } else {
      return false;
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function UpdatePassword(old, new_password) {
  var url = api_url + "/user/update/profile";
  var options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      "user": getCookie("v1-id"),
      "token": getCookie("v1-token"),
      "password": old,
      "new_password": new_password
    })
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return data["message"];
    } else {
      return false;
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function BuyPost(post, captcha) {
  var url = api_url + "/social/buy";
  var options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      "user": getCookie("v1-id"),
      "token": getCookie("v1-token"),
      "captcha": captcha,
      "post": post
    })
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return true;
    } else {
      return data["message"];
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function VerifyToken() {
  var url = api_url + "/user/verify-token";
  var options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      "user": getCookie("v1-id"),
      "token": getCookie("v1-token")
    })
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    return data["success"];
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function GetComments(post) {
  var url = api_url + "/social/comment?post=" + post;
  var options = {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return data["data"];
    } else {
      return false;
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function LikeComment(id, post) {
  var url = api_url + "/social/comment/like";
  var options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      "user": getCookie("v1-id"),
      "token": getCookie("v1-token"),
      "post": post,
      "comment": id
    })
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return true;
    } else {
      return false;
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function CommentLiked(id, comment) {
  var url = api_url + "/social/comment/liked";
  var options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      "user": getCookie("v1-id"),
      "token": getCookie("v1-token"),
      "post": id,
      "comment": comment
    })
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return data;
    } else {
      return false;
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}
function CreateComment(data, post, parent, captcha) {
  var url = api_url + "/social/comment";
  var options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      "user": getCookie("v1-id"),
      "token": getCookie("v1-token"),
      "data": data,
      "parent": parent,
      "post": post,
      "captcha": captcha
    })
  };
  return fetch(url, options).then(function (response) {
    return response.json();
  }).then(function (data) {
    if (data["success"]) {
      return true;
    } else {
      return false;
    }
  })["catch"](function (error) {
    console.error('There was a problem with the request:', error);
    return false;
  });
}

},{"./cookies.mjs":30,"@babel/core/lib/errors/rewrite-stack-trace":1}],30:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.checkCookie = checkCookie;
exports.getCookie = getCookie;
exports.setCookie = setCookie;
function setCookie(cname, cvalue, exdays) {
  var d = new Date();
  d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
  var expires = "expires=" + d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}
function getCookie(cname) {
  var name = cname + "=";
  var ca = document.cookie.split(';');
  for (var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}
function checkCookie(cname) {
  var user = getCookie(cname);
  return user != "";
}

},{}],31:[function(require,module,exports){
module.exports={
    "meta": {
        "name": "Default Blockcoin Theme",
        "id": "default",
        "author": "Herasium",
        "version": 1
    },
    "data": {
        "background": {
          "color": "black",
          "elipse-color": ["#B803FF", "#0771FF"],
          "blur": "136.5px"
        },
        "text": {
          "font": "Poppins",
          "font-code": "Poppins",
          "color": "white",
          "size": ["16px", "24px", "32px", "48px", "64px", "300px"],
          "font-weight": 400,
          "font-weight-light": 300,
          "font-weight-bold": 700,
          "border": "none",
          "button-decoration": "underline",
          "link-cursor": "pointer",
          "link-decoration": "none"
        },
        "badge": {
          "color": "white",
          "border-radius": "none",
          "border": "none"
        },
        "post": {
          "border": "solid white 1px",
          "border-radius": "16px",
          "background": "black"
        },
        "comment": {
          "border": "solid white 1px",
          "border-radius": "16px",
          "background": "black"
        },
        "navbar": {
          "background": "none",
          "blur": "10px"
        },
        "global": {
          "border-radius": ["16px", "32px", "64px"],
          "border": "solid white 1px",
          "background": "none",
          "z-index": [0, 10]
        },
        "notification": {
          "background": "none",
          "border": "solid white 1px",
          "border-radius": "16px",
          "icon-color": "white"
        },
        "new": {
          "background":"white",
          "color":"black",
          "border":"none"
        },
        "logo": {
          "url":"https://blockcoin.social/assets/logo.png"
        }
      }
      
}

},{}]},{},[11]);
